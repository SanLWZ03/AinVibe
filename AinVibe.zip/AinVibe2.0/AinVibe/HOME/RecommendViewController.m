//
//  RecommendViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "RecommendViewController.h"
#import "RecommendTableViewCell.h"
#import "OthersProfileViewController.h"
#import "AFNetworking.h"

@interface RecommendViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *recommendTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation RecommendViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title=@"达人推荐";//设置标题
    [self fetchUserInfomation];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.recommendTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.recommendTableView.delegate = self;
    self.recommendTableView.dataSource = self;
    //添加到ViewController的视图中
    [self.view addSubview:self.recommendTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    RecommendTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [RecommendTableViewCell recommendTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
//    [self.recommendTableView deselectRowAtIndexPath:indexPath animated:YES];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    NSString *picUrl=_dataArray[rowNO][@"user_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:picUrl]];//转化为data
    cell.image.image = [UIImage imageWithData:data];             //图片
    cell.image.contentMode=UIViewContentModeScaleAspectFill;
    cell.image.clipsToBounds=YES;
    if([_dataArray[rowNO][@"user_tag"] isEqualToString: @"braids"]){
        cell.userTag.text = @"脏辫师";
    }
    else if([_dataArray[rowNO][@"user_tag"] isEqualToString: @"tattoo"]){
        cell.userTag.text = @"纹身师";
    }
    else if([_dataArray[rowNO][@"user_tag"] isEqualToString: @"producer"]){
        cell.userTag.text = @"制作人";
    }
    cell.userTag.font=[UIFont systemFontOfSize:14.0];
    cell.userTag.textColor = [UIColor blackColor];
    cell.name.text = _dataArray[rowNO][@"user_name"];
    cell.name.font=[UIFont systemFontOfSize:16.0];
    cell.name.textColor = [UIColor blackColor];
    cell.name.lineBreakMode = NSLineBreakByWordWrapping;
    cell.name.numberOfLines = 0;
    //上传者的签名
    cell.intro.text =_dataArray[rowNO][@"user_intro"];
    cell.intro.font=[UIFont systemFontOfSize:16.0];
    cell.intro.lineBreakMode = NSLineBreakByWordWrapping;
    cell.intro.numberOfLines = 1;
    cell.intro.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 100;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        OthersProfileViewController *profileVC = [[OthersProfileViewController alloc]init];
        NSIndexPath *cellIndexPath = [self.recommendTableView indexPathForSelectedRow];
        RecommendTableViewCell *currentCell = [self.recommendTableView cellForRowAtIndexPath:cellIndexPath];
        profileVC.username = currentCell.name.text;
        [self.navigationController pushViewController:profileVC animated:YES];
  
}
- (void)fetchUserInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/user_info/information_all" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];
        //        [self config];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

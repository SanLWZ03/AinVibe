//
//  HotCDTableViewCell.m
//  AinVibe
//
//  Created by DMT on 2018/12/24.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "HotCDTableViewCell.h"

@implementation HotCDTableViewCell
+(instancetype)hotCDTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"HotCDTableViewCell" owner:nil options:nil] lastObject];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

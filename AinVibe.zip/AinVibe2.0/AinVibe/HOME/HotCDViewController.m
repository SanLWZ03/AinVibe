//
//  HotCDViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/24.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "HotCDViewController.h"
#import "HotCDTableViewCell.h"
#import "AFNetworking.h"
@interface HotCDViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *hotCDTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation HotCDViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title=@"热门CD";//设置标题
    [self fetchCDInfomation];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.hotCDTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.hotCDTableView.delegate = self;
    self.hotCDTableView.dataSource = self;
    //添加到ViewController的视图中
    [self.view addSubview:self.hotCDTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    HotCDTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [HotCDTableViewCell hotCDTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    NSString *cdsUrl=_dataArray[rowNO][@"cd_pic"];
    NSData * data1 = [NSData dataWithContentsOfURL:[NSURL URLWithString:cdsUrl]];//转化为data
    cell.albumPic.image = [UIImage imageWithData:data1];             //图片
    cell.albumPic.contentMode=UIViewContentModeScaleAspectFill;
    cell.albumPic.clipsToBounds=YES;
    cell.albumName.text = _dataArray[rowNO][@"cd_name"];
    cell.albumSinger.text = _dataArray[rowNO][@"cd_producer"];
    cell.albumPrice.text = [NSString stringWithFormat:@"%@",_dataArray[rowNO][@"cd_price"]];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 160;
}
- (void)fetchCDInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/cds" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

//
//  HotCDTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/24.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HotCDTableViewCell : UITableViewCell
+(instancetype)hotCDTableViewCell;
@property (weak, nonatomic) IBOutlet UIImageView *albumPic;
@property (weak, nonatomic) IBOutlet UILabel *albumName;
@property (weak, nonatomic) IBOutlet UILabel *albumSinger;
@property (weak, nonatomic) IBOutlet UILabel *albumPrice;
@end

NS_ASSUME_NONNULL_END

//
//  HomePageViewController.m
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "HomePageViewController.h"
#import "HotBeatsViewController.h"
#import "CycleView.h"
#import "RecommendViewController.h"
#import "HotCDViewController.h"
#import "AFNetworking.h"
#import "AppDelegate.h"
@interface HomePageViewController ()<UIScrollViewDelegate,CycleViewDelegate>
@property (nonatomic, retain)NSTimer* bannerTimer;  //让视图自动切换
@property (nonatomic, retain)UIPageControl *bannerPageControl;
@property(nonatomic,strong)UIScrollView *banner;
@property (nonatomic, strong) NSMutableArray *titles;//用于储存本地数据库中读取的新闻标题
@end

@implementation HomePageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self login];
    // Do any additional setup after loading the view from its nib.
    
    [self fetchFeed];

}
-(void)loadMainView{
#pragma mark -- 导航栏
    //导航栏相关设置 start————————————————————————————————————————————————————————————————————————————————————————
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    self.navigationController.navigationBar.translucent=NO;
    self.navigationController.navigationBar.barTintColor=navColor;//设置背景颜色
    self.navigationItem.title=@"AinVibe";//设置标题
    NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    self.navigationController.navigationBar.titleTextAttributes =dic;//设置字体颜色
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:self action:nil];
    backItem.tintColor=[UIColor whiteColor];//设置返回按钮的颜色，同时上一句去掉了原本的返回语句
    self.navigationItem.backBarButtonItem = backItem;
    //导航栏相关设置 end————————————————————————————————————————————————————————————————————————————————————————
    
    CGRect mainScrollViewSize=CGRectMake(0,0, 375, 675);//home界面主要SCROLL VIEW      11.29
    CGRect mainSize=mainScrollViewSize;
    mainSize.size.height=2089;
    UIScrollView *homeMainScrollView= [[UIScrollView alloc]initWithFrame:mainScrollViewSize];
    homeMainScrollView.backgroundColor=[UIColor colorWithRed:246.0/255.0 green:246.0/255.0 blue:246.0/255.0 alpha:1];
    [self.view addSubview:homeMainScrollView];
#pragma mark -- 轮播图
    //banner start 轮播图待做————————————————————————————————————————————————————————————————
    CGRect bannerSize=CGRectMake(0, 0, 375, 200);
    UIView *bannerView=[[UIView alloc]initWithFrame:bannerSize];
    CycleView *myView = [[CycleView alloc]
                         initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width,
                                                  200)];
    
    NSArray *picDataArray = @[ @"21savage1", @"wiz1", @"paris", @"21savage2"];
    
    myView.picDataArray = [picDataArray copy];
    myView.isAutomaticScroll = YES;
    
    myView.automaticScrollDelay = 2;
    
    myView.cycleViewStyle = CycleViewStyleBoth;
    
    myView.pageControlTintColor = [UIColor blackColor];
    
    myView.pageControlCurrentColor = navColor;
    myView.delegate = self;
    
    [bannerView addSubview:myView];
    [homeMainScrollView addSubview:bannerView];
    //bannner end————————————————————————————————————————————————————————————————
#pragma mark -- 热门伴奏
    //home hot beats view start————————————————————————————————————————————————————————————————
    CGRect hotBeatsSize=CGRectMake(0, 200, 375, 200);
    UIView *homeHotBeatsView=[[UIView alloc]initWithFrame:hotBeatsSize];
    homeHotBeatsView.backgroundColor=[UIColor whiteColor];
    UIButton *hotBeatsButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏按钮
    hotBeatsButton.frame=CGRectMake(15,5, 80, 40);
    //hotBeatsButton.backgroundColor=[UIColor redColor];
    [hotBeatsButton setTitle:@"热门伴奏" forState:UIControlStateNormal];
    [hotBeatsButton setTitleColor:navColor forState:UIControlStateNormal];
    [hotBeatsButton addTarget:self action:@selector(toHotBeatsView) forControlEvents:UIControlEventTouchUpInside];
    [homeHotBeatsView addSubview:hotBeatsButton];//添加按钮到view中
    
    UIImageView *hottestBeat=[[UIImageView alloc] init];// 最热门伴奏图片
    hottestBeat.image=[UIImage imageNamed:@"UnderPressure.jpg"];
    hottestBeat.frame=CGRectMake(25, 45, 120, 120);
    [homeHotBeatsView addSubview:hottestBeat];//添加图片到view中
    
    UIButton *hotBeats1=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏1
    hotBeats1.frame=CGRectMake(160,45, 200, 15);
    hotBeats1.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;//让按钮的文字向左对其
    hotBeats1.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);//按钮向左对齐但是有10的距离
    [hotBeats1 setTitle:@"1.Horns  - DJ Sunny" forState:UIControlStateNormal];
    [hotBeats1 setTitleColor:navColor forState:UIControlStateNormal];
    [homeHotBeatsView addSubview:hotBeats1];//添加歌曲1到view中
    
    UIButton *hotBeats2=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏2
    hotBeats2.frame=CGRectMake(160,70, 200, 15);
    hotBeats2.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    hotBeats2.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    [hotBeats2 setTitle:@"2.june moon.  - digit" forState:UIControlStateNormal];
    [hotBeats2 setTitleColor:navColor forState:UIControlStateNormal];
    [homeHotBeatsView addSubview:hotBeats2];//添加歌曲2到view中
    
    UIButton *hotBeats3=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏3
    hotBeats3.frame=CGRectMake(160,95, 200, 15);
    hotBeats3.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    hotBeats3.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    [hotBeats3 setTitle:@"3.Beware  - Big Sean" forState:UIControlStateNormal];
    [hotBeats3 setTitleColor:navColor forState:UIControlStateNormal];
    [homeHotBeatsView addSubview:hotBeats3];//添加歌曲3到view中
    
    UIButton *hotBeats4=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏4
    hotBeats4.frame=CGRectMake(160,120, 200, 15);
    hotBeats4.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    hotBeats4.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    [hotBeats4 setTitle:@"4.12 in the morning  - Brien" forState:UIControlStateNormal];
    [hotBeats4 setTitleColor:navColor forState:UIControlStateNormal];
    [homeHotBeatsView addSubview:hotBeats4];//添加歌曲4到view中
    
    UIButton *hotBeats5=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门伴奏5
    hotBeats5.frame=CGRectMake(160,145, 200, 15);
    hotBeats5.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    hotBeats5.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    [hotBeats5 setTitle:@"5.Wake up  - MC HOTDOG" forState:UIControlStateNormal];
    [hotBeats5 setTitleColor:navColor forState:UIControlStateNormal];
    [homeHotBeatsView addSubview:hotBeats5];//添加歌曲5到view中
    
    [homeMainScrollView addSubview:homeHotBeatsView];//将home hot beats View添加到scrollVIew中
    //home hot beats view end————————————————————————————————————————————————————————————————
#pragma mark -- 达人推荐
    //home recommend view start————————————————————————————————————————————————————————————————
    CGRect recommendSize=CGRectMake(0, 406, 375, 200);
    UIView *homeRecommendView=[[UIView alloc]initWithFrame:recommendSize];
    homeRecommendView.backgroundColor=[UIColor whiteColor];
    UIButton *recommendButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];//达人推荐按钮
    recommendButton.frame=CGRectMake(15,5, 80, 40);
    [recommendButton setTitle:@"达人推荐" forState:UIControlStateNormal];
    [recommendButton setTitleColor:navColor forState:UIControlStateNormal];
    [recommendButton addTarget:self action:@selector(toRecommendView) forControlEvents:UIControlEventTouchUpInside];
    [homeRecommendView addSubview:recommendButton];//添加按钮到view中
    
    UIImageView *recommendPicture=[[UIImageView alloc] init];// 推荐用户头像
    recommendPicture.image=[UIImage imageNamed:@"aries.jpg"];
    recommendPicture.frame=CGRectMake(25, 45, 120, 120);
    [homeRecommendView addSubview:recommendPicture];//添加图片到recommend view中
    
    UIButton *recommendName=[UIButton buttonWithType:UIButtonTypeRoundedRect];//推荐用户的名字
    recommendName.frame=CGRectMake(180,80, 200, 24);
    recommendName.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    recommendName.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    recommendName.titleLabel.font=[UIFont italicSystemFontOfSize:22.0];
    [recommendName setTitle:@"Aries" forState:UIControlStateNormal];
    [recommendName setTitleColor:navColor forState:UIControlStateNormal];
    [homeRecommendView addSubview:recommendName];//添加按钮到view中
    
    UILabel *recommendIntro=[[UILabel alloc]init];//推荐用户的签名
    recommendIntro.frame=CGRectMake(190,100, 170, 72);//高度设置为三倍，因为可能需要换行
    //recommendName.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    //recommendIntro.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    recommendIntro.text = @"u cant tell a fake person real shit";
    recommendIntro.font=[UIFont systemFontOfSize:14.0];
    UIColor *introLinesColor;//签名颜色预设 #B4B4B4   (180 180 180)
    introLinesColor=[UIColor colorWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:1];
    recommendIntro.textColor = introLinesColor;
    recommendIntro.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
    recommendIntro.numberOfLines = 0;//设置label文字显示的行数，默认值为：1，只用一行来显示，其他的>0的行数，文字会尽量按照设定行数来显示如果值为0：iOS会对文字自动计算所需要的行数，按照需要的行数来显示文字
    //recommendIntro.preferredMaxLayoutWidth = 445;
    [homeRecommendView addSubview:recommendIntro];//添加签名label到view中
    
    
    [homeMainScrollView addSubview:homeRecommendView];//将recommendView添加到scrollVIew中
    //home recommend view end————————————————————————————————————————————————————————————————
#pragma mark -- 热门CD
    //home hot cd view start————————————————————————————————————————————————————————————————
    CGRect hotCDSize=CGRectMake(0, 612, 375, 350);
    UIView *homeHotCdView=[[UIView alloc]initWithFrame:hotCDSize];
    homeHotCdView.backgroundColor=[UIColor whiteColor];
    
    UIButton *hotCDButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];//热门CD按钮
    hotCDButton.frame=CGRectMake(15,5, 80, 40);
    [hotCDButton setTitle:@"热门CD" forState:UIControlStateNormal];
    [hotCDButton setTitleColor:navColor forState:UIControlStateNormal];
    [hotCDButton addTarget:self action:@selector(toHotCDView) forControlEvents:UIControlEventTouchUpInside];
    [homeHotCdView addSubview:hotCDButton];//添加按钮到hot cd view中
    
    CGRect CDViewSize1=CGRectMake(25, 70, 95, 119);//cd1
    UIView *homeCdView1=[[UIView alloc]initWithFrame:CDViewSize1];
    [homeHotCdView addSubview:homeCdView1];//添加cd1view到hotcdview
    UIImageView *homeCD1=[[UIImageView alloc] init];// cd1 pic
    homeCD1.image=[UIImage imageNamed:@"XO TOUR Llif3.jpg"];
    homeCD1.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView1 addSubview:homeCD1];//添加图片到cd view中
    UIButton *cd1button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd1的名字
    cd1button.frame=CGRectMake(0,95, 95, 24);
    cd1button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd1button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd1button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd1button setTitle:@"XO TOUR Llif3" forState:UIControlStateNormal];
    [cd1button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView1 addSubview:cd1button];//添加cd1按钮到view中
    
    CGRect CDViewSize2=CGRectMake(140, 70, 95, 119);//cd2  高度不变
    UIView *homeCdView2=[[UIView alloc]initWithFrame:CDViewSize2];
    [homeHotCdView addSubview:homeCdView2];//添加cd2view到hotcdview
    UIImageView *homeCD2=[[UIImageView alloc] init];// cd2 pic
    homeCD2.image=[UIImage imageNamed:@"THE EMINEM SHOW.jpg"];
    homeCD2.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView2 addSubview:homeCD2];//添加图片到cd2 view中
    UIButton *cd2button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd2的名字
    cd2button.frame=CGRectMake(0,95, 95, 24);
    cd2button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd2button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd2button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd2button setTitle:@"THE EMINEM SHOW" forState:UIControlStateNormal];
    [cd2button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView2 addSubview:cd2button];//添加cd2按钮到view中
    
    CGRect CDViewSize3=CGRectMake(255, 70, 95, 119);//cd3  高度不变
    UIView *homeCdView3=[[UIView alloc]initWithFrame:CDViewSize3];
    [homeHotCdView addSubview:homeCdView3];//添加cd3view到hotcdview
    UIImageView *homeCD3=[[UIImageView alloc] init];// cd3 pic
    homeCD3.image=[UIImage imageNamed:@"1989.jpg"];
    homeCD3.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView3 addSubview:homeCD3];//添加图片到cd3 view中
    UIButton *cd3button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd3的名字
    cd3button.frame=CGRectMake(0,95, 95, 24);
    cd3button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd3button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd3button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd3button setTitle:@"1989" forState:UIControlStateNormal];
    [cd3button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView3 addSubview:cd3button];//添加cd3按钮到view中
    
    CGRect CDViewSize4=CGRectMake(25, 212, 95, 119);//cd4 左右距离和1 相同  高度变化
    UIView *homeCdView4=[[UIView alloc]initWithFrame:CDViewSize4];
    [homeHotCdView addSubview:homeCdView4];//添加cd4view到hotcdview
    UIImageView *homeCD4=[[UIImageView alloc] init];// cd4 pic
    homeCD4.image=[UIImage imageNamed:@"2014 Forest Hills Drive.jpg"];
    homeCD4.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView4 addSubview:homeCD4];//添加图片到cd view中
    UIButton *cd4button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd4的名字
    cd4button.frame=CGRectMake(0,95, 95, 24);
    cd4button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd4button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd4button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd4button setTitle:@"2014 Forest Hills Drive" forState:UIControlStateNormal];
    [cd4button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView4 addSubview:cd4button];//添加cd4按钮到view中
    
    CGRect CDViewSize5=CGRectMake(140, 212, 95, 119);//cd5
    UIView *homeCdView5=[[UIView alloc]initWithFrame:CDViewSize5];
    [homeHotCdView addSubview:homeCdView5];//添加cd5view到hotcdview
    UIImageView *homeCD5=[[UIImageView alloc] init];// cd5 pic
    homeCD5.image=[UIImage imageNamed:@"DAMN..jpg"];
    homeCD5.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView5 addSubview:homeCD5];//添加图片到cd view中
    UIButton *cd5button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd4的名字
    cd5button.frame=CGRectMake(0,95, 95, 24);
    cd5button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd5button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd5button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd5button setTitle:@"DAMN." forState:UIControlStateNormal];
    [cd5button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView5 addSubview:cd5button];//添加cd5按钮到view中
    
    CGRect CDViewSize6=CGRectMake(255, 212, 95, 119);//cd6
    UIView *homeCdView6=[[UIView alloc]initWithFrame:CDViewSize6];
    [homeHotCdView addSubview:homeCdView6];//添加cd6view到hotcdview
    UIImageView *homeCD6=[[UIImageView alloc] init];// cd4 pic
    homeCD6.image=[UIImage imageNamed:@"Illmatic XX.jpg"];
    homeCD6.frame=CGRectMake(0, 0, 95, 95);
    [homeCdView6 addSubview:homeCD6];//添加图片到cd view中
    UIButton *cd6button=[UIButton buttonWithType:UIButtonTypeRoundedRect];//cd6的名字
    cd6button.frame=CGRectMake(0,95, 95, 24);
    cd6button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    cd6button.titleLabel.font=[UIFont systemFontOfSize:12.0];
    cd6button.titleLabel.lineBreakMode=NSLineBreakByTruncatingTail;    //结尾部分的内容以……方式省略，显示头的文字内容
    [cd6button setTitle:@"Illmatic XX" forState:UIControlStateNormal];
    [cd6button setTitleColor:navColor forState:UIControlStateNormal];
    [homeCdView6 addSubview:cd6button];//添加cd6按钮到view中
    
    [homeMainScrollView addSubview:homeHotCdView];//将hot cd View添加到scrollVIew中
    //home recommend view end————————————————————————————————————————————————————————————————
#pragma mark -- 圈内新闻
    CGRect newsSize=CGRectMake(0, 968, 375, 530);
    UIView *homeNewsView=[[UIView alloc]initWithFrame:newsSize];
    homeNewsView.backgroundColor=[UIColor whiteColor];
    UIButton *newsButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];//新闻按钮
    newsButton.frame=CGRectMake(15,5, 80, 40);
    [newsButton setTitle:@"圈内新闻" forState:UIControlStateNormal];
    [newsButton setTitleColor:navColor forState:UIControlStateNormal];
    [homeNewsView addSubview:newsButton];//添加按钮到view中
    
    //CGRect newsBannerSize=CGRectMake(0, 55, 375, 180);
    CycleView *newsBannerView = [[CycleView alloc]
                                 initWithFrame:CGRectMake(0, 55, 375, 180)];
    NSArray *newsPicDataArray = @[ @"xxxx", @"nas", @"drake"];
    newsBannerView.picDataArray = [newsPicDataArray copy];
    newsBannerView.isAutomaticScroll = YES;
    newsBannerView.automaticScrollDelay = 2;
    newsBannerView.cycleViewStyle = CycleViewStyleBoth;
    newsBannerView.pageControlTintColor = [UIColor blackColor];
    newsBannerView.pageControlCurrentColor = navColor;
    newsBannerView.delegate = self;
    
    [homeNewsView addSubview:newsBannerView];
    UIView *newsBG=[[UIView alloc]initWithFrame:CGRectMake(0, 250, 375, 280)];
    newsBG.backgroundColor=[UIColor colorWithRed:250.0/255.0 green:250.0/255.0 blue:250.0/255.0 alpha:1];
    [homeNewsView addSubview:newsBG];
    UIView *firstNewsView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, 90)];//新闻1view
    firstNewsView.backgroundColor=[UIColor whiteColor];
    [newsBG addSubview:firstNewsView];
    UIImageView *newsPicture1=[[UIImageView alloc] init];// 新闻1图片
    newsPicture1.image=[UIImage imageNamed:@"xxxx"];
    newsPicture1.frame=CGRectMake(15, 0, 90, 90);
    newsPicture1.clipsToBounds=YES;
    newsPicture1.contentMode=UIViewContentModeScaleAspectFill;
    [firstNewsView addSubview:newsPicture1];//添加图片到news1 view中
    UILabel *newsTitle1=[[UILabel alloc]initWithFrame:CGRectMake(115,0, 225, 48)];//新闻1title
    newsTitle1.font=[UIFont italicSystemFontOfSize:16.0];
    newsTitle1.text=_titles[0][@"title"];
    newsTitle1.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
    newsTitle1.numberOfLines = 0;//设置label文字显示的行数，
    newsTitle1.textColor=navColor;
    [firstNewsView addSubview:newsTitle1];//添加按钮到view中
    
    UIView *secondNewsView=[[UIView alloc]initWithFrame:CGRectMake(0, 93, 375, 90)];//新闻2view
    secondNewsView.backgroundColor=[UIColor whiteColor];
    [newsBG addSubview:secondNewsView];
    UIImageView *newsPicture2=[[UIImageView alloc] init];// 新闻2图片
    newsPicture2.image=[UIImage imageNamed:@"nas"];
    newsPicture2.frame=CGRectMake(15, 0, 90, 90);
    newsPicture2.clipsToBounds=YES;
    newsPicture2.contentMode=UIViewContentModeScaleAspectFill;
    [secondNewsView addSubview:newsPicture2];//添加图片到news2view中
    UILabel *newsTitle2=[[UILabel alloc]initWithFrame:CGRectMake(115,0, 225, 48)];//新闻2title
    newsTitle2.font=[UIFont italicSystemFontOfSize:16.0];
    newsTitle2.text=_titles[1][@"title"];
    newsTitle2.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
    newsTitle2.numberOfLines = 0;//设置label文字显示的行数，
    newsTitle2.textColor=navColor;
    [secondNewsView addSubview:newsTitle2];//添加按钮到view中
    
    UIView *thirdNewsView=[[UIView alloc]initWithFrame:CGRectMake(0, 186, 375, 90)];//新闻3view
    thirdNewsView.backgroundColor=[UIColor whiteColor];
    [newsBG addSubview:thirdNewsView];
    UIImageView *newsPicture3=[[UIImageView alloc] init];// 新闻3图片
    newsPicture3.image=[UIImage imageNamed:@"drake"];
    newsPicture3.frame=CGRectMake(15, 0, 90, 90);
    newsPicture3.clipsToBounds=YES;
    newsPicture3.contentMode=UIViewContentModeScaleAspectFill;
    [thirdNewsView addSubview:newsPicture3];//添加图片到news3view中
    UILabel *newsTitle3=[[UILabel alloc]initWithFrame:CGRectMake(115,0, 225, 48)];//新闻3title
    newsTitle3.font=[UIFont italicSystemFontOfSize:16.0];
    newsTitle3.text=_titles[2][@"title"];
    newsTitle3.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
    newsTitle3.numberOfLines = 0;//设置label文字显示的行数，
    newsTitle3.textColor=navColor;
    [thirdNewsView addSubview:newsTitle3];//添加按钮到view中
    [homeMainScrollView addSubview:homeNewsView];//将newsView添加到scrollVIew中
#pragma mark -- 个性化推送1
    UIView *personalizedPost1=[[UIView alloc]initWithFrame:CGRectMake(0, 1503, 375, 400)];
    personalizedPost1.backgroundColor=[UIColor whiteColor];
    [homeMainScrollView addSubview:personalizedPost1];
    UIImageView *personalizedPost1FromPic=[[UIImageView alloc] init];//touxiang
    personalizedPost1FromPic.image=[UIImage imageNamed:@"1807-GiGi"];
    personalizedPost1FromPic.frame=CGRectMake(15, 15, 40, 40);
    personalizedPost1FromPic.clipsToBounds=YES;
    //圆形头像绘制
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:personalizedPost1FromPic.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:personalizedPost1FromPic.bounds.size];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    //设置大小
    maskLayer.frame = personalizedPost1FromPic.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    personalizedPost1FromPic.layer.mask = maskLayer;
    personalizedPost1FromPic.contentMode=UIViewContentModeScaleAspectFill;
    [personalizedPost1 addSubview:personalizedPost1FromPic];
    UILabel *personalizedPost1FromName=[[UILabel alloc]initWithFrame:CGRectMake(65,25, 200, 25)];
    personalizedPost1FromName.font=[UIFont systemFontOfSize:20.0];
    personalizedPost1FromName.text=@"1807-GiGi";
    personalizedPost1FromName.textColor=navColor;
    [personalizedPost1 addSubview:personalizedPost1FromName];
    UIImageView *post1Pic=[[UIImageView alloc]initWithFrame:CGRectMake(15,70, 345, 280)];//post pic
    post1Pic.image=[UIImage imageNamed:@"gigipost1"];
    post1Pic.clipsToBounds=YES;
    post1Pic.contentMode=UIViewContentModeScaleAspectFill;
    [personalizedPost1 addSubview:post1Pic];
    UILabel *post1sentence=[[UILabel alloc]initWithFrame:CGRectMake(25,365, 325, 20)];
    post1sentence.font=[UIFont systemFontOfSize:16.0];
    post1sentence.text=@"chilling";
    post1sentence.textColor=navColor;
    [personalizedPost1 addSubview:post1sentence];
#pragma mark -- 个性化推送2
    UIView *personalizedPost2=[[UIView alloc]initWithFrame:CGRectMake(0, 1909, 375, 180)];
    personalizedPost2.backgroundColor=[UIColor whiteColor];
    [homeMainScrollView addSubview:personalizedPost2];
    UIImageView *post2Pic=[[UIImageView alloc]initWithFrame:CGRectMake(15,15, 150, 150)];//post pic
    post2Pic.image=[UIImage imageNamed:@"bluePills"];
    post2Pic.clipsToBounds=YES;
    post2Pic.contentMode=UIViewContentModeScaleAspectFill;
    [personalizedPost2 addSubview:post2Pic];
    UILabel *post2sentence=[[UILabel alloc]initWithFrame:CGRectMake(190,25, 170, 48)];//sentence
    post2sentence.font=[UIFont systemFontOfSize:16.0];
    post2sentence.text=@"My new album is out now,check it out. ";
    post2sentence.lineBreakMode = NSLineBreakByWordWrapping;
    post2sentence.numberOfLines = 0;
    post2sentence.textColor=navColor;
    [personalizedPost2 addSubview:post2sentence];
    UIImageView *personalizedPost2FromPic=[[UIImageView alloc] init];//touxiang
    personalizedPost2FromPic.image=[UIImage imageNamed:@"metroboomin"];
    personalizedPost2FromPic.frame=CGRectMake(180, 120, 40, 40);
    personalizedPost2FromPic.clipsToBounds=YES;
    //圆形头像绘制
    UIBezierPath *maskPath2 = [UIBezierPath bezierPathWithRoundedRect:personalizedPost2FromPic.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:personalizedPost2FromPic.bounds.size];
    CAShapeLayer *maskLayer2 = [[CAShapeLayer alloc]init];
    //设置大小
    maskLayer2.frame = personalizedPost2FromPic.bounds;
    //设置图形样子
    maskLayer2.path = maskPath2.CGPath;
    personalizedPost2FromPic.layer.mask = maskLayer2;
    personalizedPost2FromPic.contentMode=UIViewContentModeScaleAspectFill;
    [personalizedPost2 addSubview:personalizedPost2FromPic];
    UILabel *personalizedPost2FromName=[[UILabel alloc]initWithFrame:CGRectMake(230,130, 130, 25)];//slogon
    personalizedPost2FromName.font=[UIFont systemFontOfSize:20.0];
    personalizedPost2FromName.text=@"Metro Boomin";
    personalizedPost2FromName.textColor=navColor;
    [personalizedPost2 addSubview:personalizedPost2FromName];
    
    
    homeMainScrollView.contentSize=mainSize.size;//scroll view 大小
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self){
        //设置标签项的标题
        self.tabBarItem.title = @"HOME";
        
        //从图像文件创建一个UIImage对象，在retina屏幕上会加载hyno@2x.png
        UIImage *i = [UIImage imageNamed:@"home.png"];
        //将对象赋给标签项的Image
        self.tabBarItem.image = i;
    }
    return self;
}
- (void)fetchFeed
{
    AppDelegate *app = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    FMDatabase *db=[app shareDb];
    FMResultSet *rs = [db executeQuery:@"select title from courses"];
    _titles = [[NSMutableArray alloc] init];
    while ([rs next]) {
        NSDictionary* dic=@{@"title":[rs stringForColumn:@"title"]};
        NSLog(@"%@ asfasfasdfdsgdfdhdf", dic[@"title"]);
        [_titles addObject:dic];
    }
    [self loadMainView];
}
-(void)toHotBeatsView
{
    HotBeatsViewController *hotBeats = [[HotBeatsViewController alloc]init];
    [self.navigationController pushViewController:hotBeats animated:YES];
}
-(void)toRecommendView
{
    RecommendViewController *recVC = [[RecommendViewController alloc]init];
    [self.navigationController pushViewController:recVC animated:YES];
}
-(void)toHotCDView
{
    HotCDViewController *hotCDVC = [[HotCDViewController alloc]init];
    [self.navigationController pushViewController:hotCDVC animated:YES];
}
@end

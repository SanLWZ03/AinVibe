//
//  ChangeProfileBgModalViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/4.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "ChangeProfileBgModalViewController.h"

@interface ChangeProfileBgModalViewController ()
@property (weak, nonatomic) IBOutlet UIView *cancelView;
@property (weak, nonatomic) IBOutlet UIView *affirmChangeView;
@property (weak, nonatomic) IBOutlet UIView *staticView;

@end

@implementation ChangeProfileBgModalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
//    CGRect darksize=CGRectMake(0,0, 414, 736);//覆盖整个界面的阴影
//    UIView *dark=[[UIView alloc]initWithFrame:darksize];
//    dark.backgroundColor=[UIColor colorWithRed:163.0/255.0 green:163.0/255.0 blue:163.0/255.0 alpha:0.3];
//    [self.view addSubview:dark];
//    
//    CGRect buttonViewSize=CGRectMake(0,500, 414, 236);//按钮区域
    _cancelView.userInteractionEnabled = YES;//打开交互
    UITapGestureRecognizer * tapBackground = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backToProfile)];
    [_cancelView addGestureRecognizer:tapBackground];
    
    _staticView.userInteractionEnabled = YES;//打开交互
    
    //绘制自定数目圆角 要设置的圆角 使用“|”来组合
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_staticView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(20, 20)];//左上和右上
//    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_staticView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerBottomRight cornerRadii:CGSizeMake(20, 20)];//左上和右下
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    
    //设置大小
    maskLayer.frame = _staticView.bounds;
    
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    
    _staticView.layer.mask = maskLayer;
    //绘制自定数目圆角-------------------------------------------------------end
    _staticView.clipsToBounds=YES;
    
    _affirmChangeView.userInteractionEnabled = YES;//打开交互
    UITapGestureRecognizer * tapProfileBackgroundPic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tappedChangeProfileBackgroundPic)];
    _affirmChangeView.backgroundColor=[UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1];
//    UILongPressGestureRecognizer *longPressAffirm=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAffirm)];
//    [_affirmChangeView addGestureRecognizer:longPressAffirm];
    [_affirmChangeView addGestureRecognizer:tapProfileBackgroundPic];
}
-(void)backToProfile
{
    NSLog(@"taping  view");
    [self dismissViewControllerAnimated:NO completion:nil];
    self.presentingViewController.tabBarController.tabBar.hidden = NO;
}
-(void)tappedChangeProfileBackgroundPic
{
    [self dismissViewControllerAnimated:NO completion:nil];
    self.presentingViewController.tabBarController.tabBar.hidden = NO;
    [[NSNotificationCenter  defaultCenter]postNotificationName:@"didTappedChangeProfileBackgroundPic" object:nil];
}
//-(void)longPressAffirm
//{
//   _affirmChangeView.backgroundColor=[UIColor colorWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:1];
//}
@end

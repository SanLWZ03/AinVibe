//
//  ProfilePicModalViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/4.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "ProfilePicModalViewController.h"
#import "PersonalViewController.h"
#import "AFNetworking.h"

@interface ProfilePicModalViewController ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UIView *others;
@property (weak, nonatomic) IBOutlet UIImageView *bigImage;
@property (weak, nonatomic) IBOutlet UIButton *changeButton;
@property (nonatomic,strong) NSString *photoUrl;//上传背景图片的路径
@end

@implementation ProfilePicModalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    
    _bigImage.image=_biggerPicture;//正向传值
    //_bigImage.backgroundColor=[UIColor whiteColor];
    //_bigImage.contentMode=UIViewContentModeScaleAspectFill;
    
    _others.userInteractionEnabled = YES;//打开交互
    UITapGestureRecognizer * tapBackground = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(backToProfile)];
    [_others addGestureRecognizer:tapBackground];
    _changeButton.userInteractionEnabled = YES;//打开交互
    _changeButton.backgroundColor=navColor;
    _changeButton.layer.cornerRadius=15;
    UITapGestureRecognizer * tapButton = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headClick)];
    [_changeButton addGestureRecognizer:tapButton];
  
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}
-(void)backToProfile
{
    NSLog(@"tapped background");
    
    if (self.returnPicBlock) // 如果在上一个页面调用了这个block，就执行下面的方法
    {
        self.returnPicBlock(self.bigImage.image); //把这里的值当参数传递过去
    }
    [self dismissViewControllerAnimated:NO completion:nil];
    self.presentingViewController.tabBarController.tabBar.hidden = NO;
}
//-(void)changePic
//{
//    [self dismissViewControllerAnimated:NO completion:nil];
//    self.presentingViewController.tabBarController.tabBar.hidden = NO;
//    [[NSNotificationCenter  defaultCenter]postNotificationName:@"didTappedChangeProfilePic" object:nil];
//}
#pragma mark -头像UIImageview的点击事件-
- (void)headClick {
    //自定义消息框
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"Choose" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Photo", nil];
    sheet.tag = 2550;
    //显示消息框
    [sheet showInView:self.view];
}
#pragma mark -消息框代理实现-
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (actionSheet.tag == 2550) {
        NSUInteger sourceType = 0;
        // 判断系统是否支持相机
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePickerController.delegate = self; //设置代理
            imagePickerController.allowsEditing = YES;
            imagePickerController.sourceType = sourceType; //图片来源
            if (buttonIndex == 0) {
                //拍照
                sourceType = UIImagePickerControllerSourceTypeCamera;
                imagePickerController.sourceType = sourceType;
                [self presentViewController:imagePickerController animated:YES completion:nil];
            }else if (buttonIndex == 1){
                //相册
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                imagePickerController.sourceType = sourceType;
                [self presentViewController:imagePickerController animated:YES completion:nil];
            }
        }else {
            sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            imagePickerController.sourceType = sourceType;
            [self presentViewController:imagePickerController animated:YES completion:nil];
        }
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    // 选取完图片后跳转回原控制器
    [picker dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    self.bigImage.image = image;
    
//    NSString *imageDocPath = [self getImageSavePath];//保存
//    _photoUrl = imageDocPath;
//    NSLog(@"imageDocPath == %@", imageDocPath);
    [self uploadImage:image];
}
//在这里创建一个路径，用来在照相的代理方法里作为照片存储的路径
//-(NSString *)getImageSavePath{
//    //获取存放的照片
//    //获取Documents文件夹目录
//    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentPath = [path objectAtIndex:0];
//    //指定新建文件夹路径
//    NSString *imageDocPath = [documentPath stringByAppendingPathComponent:@"ProfilePhotoFile"];
//    [UIImagePNGRepresentation(self.bigImage.image) writeToFile:imageDocPath atomically:YES];//n保存到沙盒
//    return imageDocPath;
//}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
    self.presentingViewController.tabBarController.tabBar.hidden = NO;
}
- (void)fetchUserInfomation //取得后台d用户信息
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/user_info/information" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        NSString *picUrl=responseObject[0][@"user_pic"];//设置背景图片路径
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:picUrl]];//转化为data
        self->_bigImage.image = [UIImage imageWithData:data];//设置背景图片
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)uploadImage:(UIImage *)image{
    
    //此处image是在项目中自取的image,读者注意自己拿到图片的方式,测试的话可以在项目中加入一张11.png的图片
    //    UIImage *image = [UIImage imageNamed:@"avator"];
    //下面是iOS两种获取图片的方法，一种获取为jpeg，一种获取为png
    //转为jpeg上传可以让图片的大小压缩
    
    
    NSMutableArray *photos = [NSMutableArray array];
    [photos addObject:image];
    
    //temp为服务器URL;
    NSString *url = @"http://172.20.10.2:3000/upload_image/upload_image_profile";
    
    NSDictionary *paramDict = @{
                                @"username":[[NSUserDefaults standardUserDefaults] objectForKey:@"name"]
                                };
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:url parameters:paramDict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //参数name：是后台给你的图片在服务器上字段名;
        //参数fileNmae：自己起得一个名字，
        //参数mimeType：这个是决定于后来接收什么类型的图片，接收的时png就用image/png ,接收的时jpeg就用image/jpeg
        
        for (int i = 0; i < photos.count; i++) {
            NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
            formatter.dateFormat=@"yyyyMMddHHmmss";
            NSString *str=[formatter stringFromDate:[NSDate date]];
            NSString *fileName=[NSString stringWithFormat:@"%@.jpg",str];
            UIImage *image = photos[i];
            NSData *imageData = UIImageJPEGRepresentation(image, 0.28);
            //            [formData appendPartWithFileData:imageData name:[NSString stringWithFormat:@"%@upload%d", [[NSUserDefaults standardUserDefaults] objectForKey:@"username"], i+1] fileName:fileName mimeType:@"image/jpeg"];
            [formData appendPartWithFileData:imageData name:@"img" fileName:fileName mimeType:@"image/jpeg"];
        }
        //        [formData appendPartWithFileData:imageData name:@"Filedata" fileName:@"Filedate.png" mimeType:@"image/png"];
        
        
    } error:nil];
    
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    //设置服务器返回内容的接受格式
    AFHTTPResponseSerializer *responseSer = [AFHTTPResponseSerializer serializer];
    responseSer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
    manager.responseSerializer = responseSer;
    
    //    NSProgress *progress = nil;
    
    NSURLSessionUploadTask *uploadTask = [manager uploadTaskWithStreamedRequest:request progress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        
        if (error) {
            NSLog(@"Error: %@", error);
            
        } else {
            
            NSString *str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            
            NSLog(@"%@\n %@", response, str);
        }
    }];
    
    [uploadTask resume];
    
    
}
//-(void)uploadImage{//上传图片
//    //1.创建管理者对象
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    //2.上传文件,在这里我们还要求传别的参数，用字典保存一下，不需要的童鞋可以省略此步骤
//    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:_photoUrl,@"photo_url", nil];
//
//
//    //post请求
//    [manager POST:@"http://172.20.10.2:3000/upload_image/upload_profile_image" parameters:dict  progress:^(NSProgress * _Nonnull
//                                                                                                   uploadProgress) {
//
//        //打印下上传进度
//        NSLog(@"%lf",1.0 *uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//
//        //请求成功
//        NSLog(@"请求成功：%@",responseObject);
//
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//
//        //请求失败
//        NSLog(@"请求失败：%@",error);
//    }];
//}
@end

//
//  TweetsViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/15.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "TweetsViewController.h"
#import "AFNetworking.h"
#import "TweetsTableViewCell.h"

@interface TweetsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tweetsTableView;
@property (strong,nonatomic) UIImageView *uploaderSourse;
@property (strong,nonatomic) UILabel *uploaderNameSource;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation TweetsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    NSLog(@"%@----twweets", _usernameForTweets);
    [self fetchUserInfomation];
    [self fetchPosts];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.tweetsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.tweetsTableView.delegate = self;
    self.tweetsTableView.dataSource = self;
    
    [self.view addSubview:self.tweetsTableView];
    [self.tweetsTableView reloadData];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    TweetsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [TweetsTableViewCell tweetsTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    self.tweetsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;//取消分割线
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//取消CELL的点击效果
    cell.posterPic.image = _uploaderSourse.image;             //图片
    cell.posterPic.contentMode=UIViewContentModeScaleAspectFill;
    cell.posterPic.clipsToBounds=YES;
    cell.posterName.text = _uploaderNameSource.text;
    cell.postTime.text = _dataArray[rowNO][@"post_time"];
    cell.postContent.text = _dataArray[rowNO][@"post_content"];
    NSString *postUrl=_dataArray[rowNO][@"post_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:postUrl]];//转化为data
    cell.postPics.image = [UIImage imageWithData:data];             //图片
    cell.postPics.contentMode=UIViewContentModeScaleAspectFill;
    cell.postPics.clipsToBounds=YES;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 450;
}

- (void)fetchUserInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    NSDictionary *paramDict = @{
                                @"apicode":@"posterinfo",
                                //                                @"user_account":_accountField.text
                                @"args":@{
                                        @"user_name":_usernameForTweets,
                                        //                                        @"user_password":_passwordField.text,
                                        }
                                };
    [manager POST:@"http://172.20.10.2:3000/user_info/poster_info" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_uploaderNameSource = [[UILabel alloc]init];
        self->_uploaderNameSource.text=responseObject[0][@"user_name"];//设置用户姓名
        NSString *profileUrl=responseObject[0][@"user_pic"];//设置r头像图片路径
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
        self->_uploaderSourse=[[UIImageView alloc]init];
        self->_uploaderSourse.image = [UIImage imageWithData:data];//设置头像图片
//        [self fetchPosts];
//        [self config];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)fetchPosts{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    NSDictionary *paramDict = @{
                                @"apicode":@"userinfo",
                                //                                @"user_account":_accountField.text
                                @"args":@{
                                        @"user_name":_usernameForTweets,
                                        //                                        @"user_password":_passwordField.text,
                                        }
                                };
    [manager POST:@"http://172.20.10.2:3000/hopData/Posts" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];//加载页面
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

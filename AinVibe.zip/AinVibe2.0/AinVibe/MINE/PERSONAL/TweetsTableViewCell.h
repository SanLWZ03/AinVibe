//
//  TweetsTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TweetsTableViewCell : UITableViewCell
+(instancetype)tweetsTableViewCell;
@property (weak, nonatomic) IBOutlet UIImageView *posterPic;
@property (weak, nonatomic) IBOutlet UILabel *posterName;
@property (weak, nonatomic) IBOutlet UILabel *postTime;
@property (weak, nonatomic) IBOutlet UILabel *postContent;
@property (weak, nonatomic) IBOutlet UIImageView *postPics;
@end

NS_ASSUME_NONNULL_END

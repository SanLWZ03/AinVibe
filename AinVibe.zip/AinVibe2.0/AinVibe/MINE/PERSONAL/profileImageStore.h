//
//  profileImageStore.h
//  AinVibe
//
//  Created by DMT on 2018/12/2.
//  Copyright © 2018年 AinVibe. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface profileImageStore : NSObject
+ (instancetype)sharedStore;

- (void)setImage:(UIImage *)image forKey:(NSString *)key;
- (UIImage *)imageForKey:(NSString *)key;
- (void)deleteImageForKey:(NSString *)key;

@end
NS_ASSUME_NONNULL_END

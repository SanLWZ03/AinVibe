//
//  PersonalViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/2.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "PersonalViewController.h"
#import "HotBeatsViewController.h"
#import "profileImageStore.h"
#import "ChangeProfileBgModalViewController.h"
#import "ProfilePicModalViewController.h"
#import "TweetsViewController.h"
#import "AboutViewController.h"
#import "EditViewController.h"
#import "AFNetworking.h"

@interface PersonalViewController ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate,UIScrollViewDelegate>
@property (strong, nonatomic) UIImageView *profileBackgroundPic;//用户背景图片
@property (strong, nonatomic) UIImageView *profilePic;//用户头像
@property (nonatomic,strong) UIScrollView *mainScrollView;//用于上下滑动
@property (nonatomic,strong) UIView *navigationView;
@property (nonatomic,strong) UILabel *sliderLabel;
@property (nonatomic,strong) UIButton *tweetsViewButton;
@property (nonatomic,strong) UIButton *aboutViewButton;
@property (nonatomic,strong) UIScrollView *personalMainScrollView;//下面的分页
@property (nonatomic,strong) TweetsViewController *tweetsVC;
@property (nonatomic,strong) AboutViewController *aboutVC;
@property (nonatomic,strong) UILabel *profileUserName;//用户名
@property (nonatomic,strong) UILabel *profileIntro;//用户签名
@property (nonatomic,strong) UIImage *uploadimage;//上传背景图片
@property (nonatomic,strong) NSString *photoUrl;//上传背景图片的路径


@end

@implementation PersonalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    

#pragma mark -- 导航栏
    //导航栏相关设置 start————————————————————————————————————————————————————————————————————————————————————————
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    self.navigationController.navigationBar.translucent=NO;
    self.navigationController.navigationBar.barTintColor=navColor;//设置背景颜色
    self.navigationItem.title=@"个人中心";//设置标题
    NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    self.navigationController.navigationBar.titleTextAttributes =dic;//设置字体
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:self action:nil];
    backItem.tintColor=[UIColor whiteColor];//设置返回按钮的颜色，同时上一句去掉了原本的语句
    //    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"user.png"] style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];//测试   用图片代替，但是返回键仍然存在 同时颜色仍然为默认
    self.navigationItem.backBarButtonItem = backItem;
 
     #pragma mark -- main scroll view
    //main scroll view start————————————————————————————————————————————————————————————————————————
    CGRect mainScrollViewSize=CGRectMake(0,0,375, 641);//personal界面主要SCROLL VIEW
    CGRect mainSize=mainScrollViewSize;
    mainSize.size.height+=250;
    _mainScrollView= [[UIScrollView alloc]initWithFrame:mainScrollViewSize];
    _mainScrollView.backgroundColor=[UIColor colorWithRed:246.0/255.0 green:246.0/255.0 blue:246.0/255.0 alpha:1];
    [self.view addSubview:_mainScrollView];
    _mainScrollView.contentSize=mainSize.size;//scroll view 大小
    //main scroll view end————————————————————————————————————————————————————————————————————————
     #pragma mark -- profile
    //profile view start————————————————————————————————————————————————————————————————————————
    CGRect profileSize=CGRectMake(0,0, 375, 270);                            //个人资料
    UIView *profileView= [[UIView alloc]initWithFrame:profileSize];
    profileView.backgroundColor=[UIColor grayColor];
    profileView.userInteractionEnabled = YES;//打开交互
    profileView.clipsToBounds=YES;//防止图片超出
    [_mainScrollView addSubview:profileView];//个人中心view添加
    //background picture
    _profileBackgroundPic=[[UIImageView alloc] init];                             // 背景图片
    _profileBackgroundPic.contentMode=UIViewContentModeScaleAspectFill;//会按照图片的宽高比来拉伸,要求整张图片必须填充UIImageView,并且图片的宽度或者高度其中一个必须和UIImageView一样,因为是按照图片的宽高比来拉伸, 所以图片不会变形
    //_profileBackgroundPic.image=[UIImage imageNamed:@"Metro.jpg"];
    _profileBackgroundPic.frame=CGRectMake(0, 0, 375, 270);//
    _profileBackgroundPic.userInteractionEnabled = YES;//打开交互
    UITapGestureRecognizer * tapProfileBackgroundPic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeProfileBackgroundModal)];
    [_profileBackgroundPic addGestureRecognizer:tapProfileBackgroundPic];
    [profileView addSubview:_profileBackgroundPic];//添加图片到view中
    //picture
    _profilePic=[[UIImageView alloc] init];                                // 个人头像
    _profilePic.userInteractionEnabled = YES;
    _profilePic.backgroundColor=[UIColor blackColor];
    UITapGestureRecognizer * tapProfilePic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeProfilePicModal)];
    [_profilePic addGestureRecognizer:tapProfilePic];
    _profilePic.image=[UIImage imageNamed:@"unknown"];
    _profilePic.frame=CGRectMake(30, 20, 130, 130);
    _profilePic.contentMode=UIViewContentModeScaleAspectFill;
    _profilePic.clipsToBounds=YES;
    //圆形头像绘制
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_profilePic.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:_profilePic.bounds.size];
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
    //设置大小
    maskLayer.frame = _profilePic.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    _profilePic.layer.mask = maskLayer;
//    _profilePic.layer.masksToBounds=YES;//遮罩
//    _profilePic.layer.cornerRadius=65.0f;
    [profileView addSubview:_profilePic];//添加图片到view中
    //username
    
    UIButton *editButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];       //修改资料按钮
    editButton.frame=CGRectMake(280,80, 60, 30);
    [editButton setTitle:@"编辑" forState:UIControlStateNormal];
    editButton.layer.cornerRadius=15;
    editButton.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:215.0/255.0 alpha:1];
    [editButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [editButton addTarget:self action:@selector(editProfile) forControlEvents:UIControlEventTouchUpInside];
    [profileView addSubview:editButton];//添加按钮到view中
    
    _profileUserName=[[UILabel alloc]init];                                   //用户名
    _profileUserName.userInteractionEnabled = YES;
    _profileUserName.frame=CGRectMake(50,165, 190, 25);
    _profileUserName.text = @"NULL";
    _profileUserName.textColor = [UIColor whiteColor];
    _profileUserName.font=[UIFont systemFontOfSize:22.0];
    [profileView addSubview:_profileUserName];//添加username到view中
    //intro
    _profileIntro=[[UILabel alloc]init];                           //用户的签名
    _profileIntro.userInteractionEnabled = YES;
    _profileIntro.frame=CGRectMake(50,190, 300, 32);//高度设置为2倍，因为可能需要换行
    _profileIntro.text = @"NULL";
    _profileIntro.font=[UIFont systemFontOfSize:16.0];
    UIColor *introLinesColor;//签名颜色预设 #F0F0F0   (240 240 240)
    introLinesColor=[UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1];
    _profileIntro.textColor = introLinesColor;
    _profileIntro.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
    _profileIntro.numberOfLines = 0;//设置label文字显示的行数，默认值为：1，只用一行来显示，其他的>0的行数，文字会尽量按照设定行数来显示如果值为0：iOS会对文字自动计算所需要的行数，按照需要的行数来显示文字
    [profileView addSubview:_profileIntro];//添加签名label到view中
    //profile view end————————————————————————————————————————————————————————————————————————
     #pragma mark -- 容纳分页的scrollview
    [self initUI];//初始化导航栏
    
    _personalMainScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 292, 375, 601)];
    _personalMainScrollView.delegate = self;
    _personalMainScrollView.backgroundColor = [UIColor whiteColor];
    _personalMainScrollView.pagingEnabled = YES;
    _personalMainScrollView.showsHorizontalScrollIndicator = NO;
    _personalMainScrollView.showsVerticalScrollIndicator = NO;
    [_mainScrollView addSubview:_personalMainScrollView];
    
    TweetsViewController *tweetsVC = [[TweetsViewController alloc]init];
    tweetsVC.usernameForTweets=_username;
    AboutViewController *aboutVC = [[AboutViewController alloc]init];
    aboutVC.usernameForAbout=_username;
//    tweetsVC.tweetsMainScrollView.scrollEnabled=NO;
    
    NSArray *views = @[tweetsVC.view, aboutVC.view];
    for (int i = 0; i < views.count; i++){
        //添加背景，把VC的view贴到mainScrollView上面
        UIView *pageView = [[UIView alloc]initWithFrame:CGRectMake(375 * i, 0, _personalMainScrollView.frame.size.width, _personalMainScrollView.frame.size.height)];
        [pageView addSubview:views[i]];
        [_personalMainScrollView addSubview:pageView];
    }
    [self addChildViewController:tweetsVC];
    [self addChildViewController:aboutVC];
    _personalMainScrollView.contentSize = CGSizeMake(375 * (views.count), 0);
    
    [self fetchUserInfomation];
//    tweetsVC.uploaderName.text=self.profileUserName.text;                        // 用户名传递到下面的分页中
}
-(void)viewWillAppear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(bgClick) name:@"didTappedChangeProfileBackgroundPic" object:nil]; //用于自动执行background 的image picker
}
#pragma mark -更换背景UIImageview的点击事件-
- (void)bgClick {
    //自定义消息框
    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:@"Choose" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera",@"Photo", nil];
    sheet.tag = 2550;
    //显示消息框
    [sheet showInView:self.view];
}
#pragma mark -消息框代理实现-
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (actionSheet.tag == 2550) {
        NSUInteger sourceType = 0;
        // 判断系统是否支持相机
        UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
            imagePickerController.delegate = self; //设置代理
            imagePickerController.allowsEditing = YES;
            imagePickerController.sourceType = sourceType; //图片来源
            if (buttonIndex == 0) {
                //拍照
                sourceType = UIImagePickerControllerSourceTypeCamera;
                imagePickerController.sourceType = sourceType;
                [self presentViewController:imagePickerController animated:YES completion:nil];
            }else if (buttonIndex == 1){
                //相册
                sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                imagePickerController.sourceType = sourceType;
                [self presentViewController:imagePickerController animated:YES completion:nil];
            }
        }else {
            sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            imagePickerController.sourceType = sourceType;
            [self presentViewController:imagePickerController animated:YES completion:nil];
        }
    }
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    // 选取完图片后跳转回原控制器
    [picker dismissViewControllerAnimated:YES completion:nil];
    _uploadimage = [info objectForKey:UIImagePickerControllerOriginalImage];
    self.profileBackgroundPic.image = _uploadimage;
    
//    NSString *imageDocPath = [self getImageSavePath];//保存
//    _photoUrl = imageDocPath;
//    NSLog(@"imageDocPath == %@", imageDocPath);
//    [self uploadImage];
    [self uploadImage:_uploadimage];
}
////在这里创建一个路径，用来在照相的代理方法里作为照片存储的路径
//-(NSString *)getImageSavePath{
//    //获取存放的照片
//    //获取Documents文件夹目录
//    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentPath = [path objectAtIndex:0];
//    //指定新建文件夹路径
//    NSString *imageDocPath = [documentPath stringByAppendingPathComponent:@"BackgroundPhotoFile"];
//    [UIImagePNGRepresentation(self.profileBackgroundPic.image) writeToFile:imageDocPath atomically:YES];//n保存到沙盒
//    return imageDocPath;
//}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}


-(void)changeProfileBackgroundModal
{
    ChangeProfileBgModalViewController *cc1=[[ChangeProfileBgModalViewController alloc]init];
    cc1.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:cc1 animated:NO completion:^{
        //cc1.view.backgroundColor = [UIColor colorWithRed:88.0/255.0 green:88.0/255.0 blue:88.0/255.0 alpha:1.0];
        cc1.view.alpha = 0.8;
    }];
    self.tabBarController.tabBar.hidden = YES; // 隐藏tabBar
}
-(void)changeProfilePicModal//更换头像
{
    ProfilePicModalViewController *profilePicModal=[[ProfilePicModalViewController alloc]init];
    profilePicModal.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    profilePicModal.biggerPicture=self.profilePic.image;
    //接受传回的图片
    profilePicModal.returnPicBlock = ^(UIImage *backPic) {
        self.profilePic.image=backPic;
    };
    [self presentViewController:profilePicModal animated:NO completion:nil];
    self.tabBarController.tabBar.hidden = YES; // 隐藏tabBar
}
-(void)editProfile
{
    EditViewController *editVC=[[EditViewController alloc]init];
    [self.navigationController pushViewController:editVC animated:YES];
}
#pragma mark - 分页的实现
//初始化UIBtton和一个滑动的UILabel，命名为sliderLabel
-(void)initUI{
    
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    _navigationView = [[UIView alloc]initWithFrame:CGRectMake(0, 250, 375, 40)];
    _navigationView.backgroundColor = [UIColor whiteColor];
    //绘制自定数目圆角 要设置的圆角 使用“|”来组合
    UIBezierPath *maskPath;
    maskPath = [UIBezierPath bezierPathWithRoundedRect:_navigationView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(15, 15)];//左上和右上
    CAShapeLayer *maskLayer;
    maskLayer = [[CAShapeLayer alloc] init];
    //设置大小
    maskLayer.frame = _navigationView.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    _navigationView.layer.mask = maskLayer;
    //绘制自定数目圆角-------------------------------------------------------end
    _navigationView.clipsToBounds=YES;
    _tweetsViewButton= [UIButton buttonWithType:UIButtonTypeCustom];
    _tweetsViewButton.frame = CGRectMake(50, 0, 90, 44);
    _tweetsViewButton.titleLabel.font = [UIFont boldSystemFontOfSize:19];
    [_tweetsViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_tweetsViewButton setTitle:@"动态" forState:UIControlStateNormal];
    [_tweetsViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _tweetsViewButton.tag = 1;
    [_navigationView addSubview:_tweetsViewButton];
    
    
    _aboutViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _aboutViewButton.frame = CGRectMake(235, 0, 90, 44);
    _aboutViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [_aboutViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_aboutViewButton setTitle:@"关于" forState:UIControlStateNormal];
    [_aboutViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _aboutViewButton.tag = 2;
    [_navigationView addSubview:_aboutViewButton];
    
    _sliderLabel = [[UILabel alloc]initWithFrame:CGRectMake(50, 36, 90, 4)];
    _sliderLabel.backgroundColor = [UIColor colorWithRed:93.0/255.0 green:194.0/255.0 blue:255.0/255.0 alpha:1];
    [_navigationView addSubview:_sliderLabel];
    //self.navigationController.navigationBar.barTintColor=navColor;
    //self.navigationController.navigationBar.translucent=NO;
    //self.navigationItem.titleView = _navigationView;
    [self.mainScrollView addSubview:_navigationView];
}


-(UIButton *)theSeletedBtn{
    if (_tweetsViewButton.selected) {
        return _tweetsViewButton;
    }else if (_aboutViewButton.selected){
        return _aboutViewButton;
    }
    else{
        return nil;
    }
}
-(UIButton *)buttonWithTag:(NSInteger)tag{//根据tag返回 按钮
    if (tag==1) {
        return _tweetsViewButton;
    }else if (tag==2){
        return _aboutViewButton;
    }else{
        return nil;
    }
}


-(void)sliderAction:(UIButton *)sender{//点击导航栏的两个按钮会到这个函数，并且会有一个sender
    [self sliderAnimationWithTag:sender.tag];//获取sender的tag值，传到sliderAnimationWithTag函数中
    [UIView animateWithDuration:0.3 animations:^{
        self.personalMainScrollView.contentOffset = CGPointMake(375 * (sender.tag - 1), 0);//根据tag的值修改scrollView的显示界面
    } completion:^(BOOL finished) {
        
    }];
    
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{//让scrollview的滑动也能触发label的滑动动画
    double index = scrollView.contentOffset.x / 375;//当前的偏移量除以屏幕宽度，就是当前横向滑动占屏幕宽度的百分比
    [self sliderAnimationWithTag:(int)(index+0.5)+1];//index+0.5是为了当屏幕滑动超过宽度的一半时 label的滑动动画就触发。(滑到一半时，index=0.5，此时，tag=2，刚好是选中第二个按钮时的tag值)
    
//    CGPoint offset = _mainScrollView.contentOffset;//偏移量
//    CGRect bounds = _mainScrollView.bounds;//显示的范围
//    CGSize size = _mainScrollView.contentSize;//可滑动的范围
//    CGFloat currentOffset = offset.y + bounds.size.height;
//    CGFloat maxOffset = size.height;//底部的偏移量
//    CGFloat minOffset = 0;//顶部
//    if((currentOffset - minOffset)>250)
//    {
//        _mainScrollView.scrollEnabled=NO;
//    _tweetsVC.tweetsMainScrollView.scrollEnabled=YES;
//    }
//    else
//    {
//        _mainScrollView.scrollEnabled=YES;
//    _tweetsVC.tweetsMainScrollView.scrollEnabled=NO;
//    }
}
#pragma mark - sliderLabel滑动动画
- (void)sliderAnimationWithTag:(NSInteger)tag{//根据传过来的tag值对选中按钮进行操作
    _tweetsViewButton.selected = NO;
    _aboutViewButton.selected = NO;
    UIButton *sender = [self buttonWithTag:tag];//将选中的按钮
    sender.selected = YES;
    //动画
    [UIView animateWithDuration:0.3 animations:^{//duration为动画持续的时间。最好和前面的sliderAction一样，否则一前一后感觉动画断开了，效果不好
        self.sliderLabel.frame = CGRectMake(sender.frame.origin.x, self.sliderLabel.frame.origin.y, self.sliderLabel.frame.size.width, self.sliderLabel.frame.size.height);//将label的位置设置为选中的下方
        
    } completion:^(BOOL finished) {
        self.tweetsViewButton.titleLabel.font = [UIFont systemFontOfSize:16];//按钮都设置为默认
        self.aboutViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
        
        sender.titleLabel.font = [UIFont boldSystemFontOfSize:19];//把选中的按钮字体加大加粗
    }];
    
}
- (void)fetchUserInfomation //取得后台d用户信息
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    NSDictionary *paramDict = @{
                                @"apicode":@"userinfo",
                                //                                @"user_account":_accountField.text
                                @"args":@{
                                        @"user_name":_username,
                                        //                                        @"user_password":_passwordField.text,
                                        }
                                };
    [manager POST:@"http://172.20.10.2:3000/user_info/detail_information" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        //        self->_profileUserName=[[UILabel alloc]init];
        //        self->_profileIntro=[[UILabel alloc]init];
        //        self->_profilePic=[[UIImageView alloc]init];
        //        self->_profileBackgroundPic=[[UIImageView alloc]init];
        if(![responseObject[0][@"user_name"] isKindOfClass:[NSNull class]]){
            self->_profileUserName.text=responseObject[0][@"user_name"];//设置用户名
        }
        if(![responseObject[0][@"user_intro"] isKindOfClass:[NSNull class]]){
            self->_profileIntro.text=responseObject[0][@"user_intro"];//设置用户签名
        }
        if(![responseObject[0][@"user_profile_bg"] isKindOfClass:[NSNull class]]){
            NSString *backgroundUrl=responseObject[0][@"user_profile_bg"];//设置背景图片路径
            
            NSData * data2 = [NSData dataWithContentsOfURL:[NSURL URLWithString:backgroundUrl]];//转化为data
            self->_profileBackgroundPic.image = [UIImage imageWithData:data2];//设置背景图片
        }
        if(![responseObject[0][@"user_pic"] isKindOfClass:[NSNull class]]){
            NSString *profileUrl=responseObject[0][@"user_pic"];//设置r头像图片路径
            NSData * data1 = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
            self->_profilePic.image = [UIImage imageWithData:data1];//设置头像图片
        }
        
        //        [self loadProfile];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)uploadImage:(UIImage *)image{
    //此处image是在项目中自取的image,读者注意自己拿到图片的方式,测试的话可以在项目中加入一张11.png的图片
    //    UIImage *image = [UIImage imageNamed:@"avator"];
    //下面是iOS两种获取图片的方法，一种获取为jpeg，一种获取为png
    //转为jpeg上传可以让图片的大小压缩
    NSMutableArray *photos = [NSMutableArray array];
    [photos addObject:image];
    
    //temp为服务器URL;
    NSString *url = @"http://172.20.10.2:3000/upload_image/upload_image_background";
    
    NSDictionary *paramDict = @{
                                @"username":[[NSUserDefaults standardUserDefaults] objectForKey:@"name"]
                                };
    
    NSMutableURLRequest *request = [[AFHTTPRequestSerializer serializer] multipartFormRequestWithMethod:@"POST" URLString:url parameters:paramDict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //参数name：是后台给你的图片在服务器上字段名;
        //参数fileNmae：自己起得一个名字，
        //参数mimeType：这个是决定于后来接收什么类型的图片，接收的时png就用image/png ,接收的时jpeg就用image/jpeg
        
        for (int i = 0; i < photos.count; i++) {
            NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
            formatter.dateFormat=@"yyyyMMddHHmmss";
            NSString *str=[formatter stringFromDate:[NSDate date]];
            NSString *fileName=[NSString stringWithFormat:@"%@.jpg",str];
            UIImage *image = photos[i];
            NSData *imageData = UIImageJPEGRepresentation(image, 0.28);
            //            [formData appendPartWithFileData:imageData name:[NSString stringWithFormat:@"%@upload%d", [[NSUserDefaults standardUserDefaults] objectForKey:@"username"], i+1] fileName:fileName mimeType:@"image/jpeg"];
            [formData appendPartWithFileData:imageData name:@"img" fileName:fileName mimeType:@"image/jpeg"];
        }
        //        [formData appendPartWithFileData:imageData name:@"Filedata" fileName:@"Filedate.png" mimeType:@"image/png"];
        
        
    } error:nil];
    
    
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    //设置服务器返回内容的接受格式
    AFHTTPResponseSerializer *responseSer = [AFHTTPResponseSerializer serializer];
    responseSer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
    manager.responseSerializer = responseSer;
    
    //    NSProgress *progress = nil;
    
    NSURLSessionUploadTask *uploadTask = [manager uploadTaskWithStreamedRequest:request progress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        
        if (error) {
            NSLog(@"Error: %@", error);
            
        } else {
            
            NSString *str = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
            
            NSLog(@"%@\n %@", response, str);
        }
    }];
    
    [uploadTask resume];
}
//-(void)uploadImage{//上传图片
//    //1.创建管理者对象
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    //2.上传文件,在这里我们还要求传别的参数，用字典保存一下，不需要的童鞋可以省略此步骤
//    NSDictionary *dict = [[NSDictionary alloc] initWithObjectsAndKeys:_photoUrl,@"photo_url", nil];
//
//
//    //post请求
//        [manager POST:@"http://172.20.10.2:3000/upload_image/upload_background_image" parameters:dict  progress:^(NSProgress * _Nonnull
//    uploadProgress) {
//
//        //打印下上传进度
//        NSLog(@"%lf",1.0 *uploadProgress.completedUnitCount / uploadProgress.totalUnitCount);
//    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//
//        //请求成功
//        NSLog(@"请求成功：%@",responseObject);
//
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//
//        //请求失败
//        NSLog(@"请求失败：%@",error);
//    }];
//}
@end

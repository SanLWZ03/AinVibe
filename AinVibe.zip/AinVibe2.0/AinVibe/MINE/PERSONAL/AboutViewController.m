//
//  AboutViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/15.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "AboutViewController.h"
#import "AFNetworking.h"

@interface AboutViewController ()
@property (nonatomic,strong) UILabel *genderDetail;//用户性别信息
@property (nonatomic,strong) UILabel *blockDetail;//用户地区信息
@property (nonatomic,strong) UILabel *ageDetail;//用户年龄信息
@property (nonatomic,strong) UILabel *introduction;//用户简介
@end

@implementation AboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UILabel *info=[[UILabel alloc]init];//个人信息
    info.userInteractionEnabled = YES;
    info.frame=CGRectMake(25,0, 190, 25);
    info.text = @"个人信息";
    info.textColor = [UIColor blackColor];
    info.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:info];
    
    UILabel *gender=[[UILabel alloc]init];//性别
    gender.userInteractionEnabled = YES;
    gender.frame=CGRectMake(25,30, 190, 25);
    gender.text = @"性别:";
    gender.textColor = [UIColor grayColor];
    gender.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:gender];
    _genderDetail=[[UILabel alloc]init];//性别内容
    _genderDetail.userInteractionEnabled = YES;
    _genderDetail.frame=CGRectMake(70,30, 190, 25);
    _genderDetail.text = @"未填写";
    _genderDetail.textColor = [UIColor grayColor];
    _genderDetail.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:_genderDetail];
    
    UILabel *block=[[UILabel alloc]init];//地区
    block.userInteractionEnabled = YES;
    block.frame=CGRectMake(25,60, 190, 25);
    block.text = @"地区:";
    block.textColor = [UIColor grayColor];
    block.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:block];
    _blockDetail=[[UILabel alloc]init];//地区内容
    _blockDetail.userInteractionEnabled = YES;
    _blockDetail.frame=CGRectMake(70,60, 190, 25);
    _blockDetail.text = @"未填写";
    _blockDetail.textColor = [UIColor grayColor];
    _blockDetail.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:_blockDetail];
    
    UILabel *age=[[UILabel alloc]init];//年龄
    age.userInteractionEnabled = YES;
    age.frame=CGRectMake(25,90, 190, 25);
    age.text = @"年龄:";
    age.textColor = [UIColor grayColor];
    age.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:age];
    _ageDetail=[[UILabel alloc]init];//年龄内容
    _ageDetail.userInteractionEnabled = YES;
    _ageDetail.frame=CGRectMake(70,90, 190, 25);
    _ageDetail.text = @"未填写";
    _ageDetail.textColor = [UIColor grayColor];
    _ageDetail.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:_ageDetail];
    
    UILabel *intro=[[UILabel alloc]init];//个人简介
    intro.userInteractionEnabled = YES;
    intro.frame=CGRectMake(25,150, 190, 25);
    intro.text = @"个人简介";
    intro.textColor = [UIColor blackColor];
    intro.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:intro];
    _introduction=[[UILabel alloc]init];//简介内容
    _introduction.userInteractionEnabled = YES;
    _introduction.frame=CGRectMake(25,180, 190, 25);
    _introduction.text = @"未填写";
    _introduction.textColor = [UIColor grayColor];
    _introduction.font=[UIFont systemFontOfSize:16.0];
    [self.view addSubview:_introduction];
    NSLog(@"%@----aboooot", _usernameForAbout);
    [self fetchUserInfomation];
}
- (void)fetchUserInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    NSDictionary *paramDict = @{
                                @"apicode":@"posterinfo",
                                //                                @"user_account":_accountField.text
                                @"args":@{
                                        @"user_name":_usernameForAbout,
                                        //                                        @"user_password":_passwordField.text,
                                        }
                                };
    [manager POST:@"http://172.20.10.2:3000/user_info/poster_info" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        if(![responseObject[0][@"user_gender"] isKindOfClass:[NSNull class]]){
            self->_genderDetail.text=responseObject[0][@"user_gender"];//设置用户性别
        }
        if(![responseObject[0][@"user_city"] isKindOfClass:[NSNull class]]){
            self->_blockDetail.text=responseObject[0][@"user_city"];//设置用户地区
        }
        if(![responseObject[0][@"user_age"] isKindOfClass:[NSNull class]]){
            self->_ageDetail.text=[NSString stringWithFormat:@"%@",responseObject[0][@"user_age"]];//设置用户年龄   数字需要转化一下
        }
        if(![responseObject[0][@"user_introduction"] isKindOfClass:[NSNull class]]){
            self->_introduction.text=responseObject[0][@"user_introduction"];//设置用户简介
        }
        
        //        [self fetchPosts];
        //        [self config];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
//- (void)fetchUserInfomation
//{
//    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
//    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//
//    [manager GET:@"http://172.20.10.2:3000/user_info/information" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
//
//        NSLog(@"%@---%@",[responseObject class],responseObject);
//        self->_genderDetail.text=responseObject[0][@"user_gender"];//设置用户性别
//        self->_blockDetail.text=responseObject[0][@"user_city"];//设置用户地区
//        self->_ageDetail.text=[NSString stringWithFormat:@"%@",responseObject[0][@"user_age"]];//设置用户年龄   数字需要转化一下
//        self->_introduction.text=responseObject[0][@"user_introduction"];//设置用户简介
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        NSLog(@"请求失败--%@",error);
//    }];
//}

@end

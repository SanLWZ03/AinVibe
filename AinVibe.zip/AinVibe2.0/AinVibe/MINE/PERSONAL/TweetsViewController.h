//
//  TweetsViewController.h
//  AinVibe
//
//  Created by DMT on 2018/12/15.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TweetsViewController : UIViewController

@property (strong, nonatomic) UIImageView *uploader;//用户头像
@property (nonatomic,strong) UIScrollView *tweetsMainScrollView;
@property (nonatomic,strong) UILabel *uploaderName;//用户名
@property (strong,nonatomic) NSString *usernameForTweets;
@end

NS_ASSUME_NONNULL_END

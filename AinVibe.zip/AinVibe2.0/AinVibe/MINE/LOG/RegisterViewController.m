//
//  RegisterViewController.m
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "RegisterViewController.h"

@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UIButton *backToLogin;

@end

@implementation RegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title=@"注册";//设置标题
    [_backToLogin addTarget:self action:@selector(toLoginView) forControlEvents:UIControlEventTouchUpInside];
}
-(void)viewWillAppear:(BOOL)animated{
    self.tabBarController.tabBar.hidden = YES; // 隐藏tabBar
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)toLoginView
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end

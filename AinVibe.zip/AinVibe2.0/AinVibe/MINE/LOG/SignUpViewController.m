//
//  SignUpViewController.m
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "SignUpViewController.h"
#import "RegisterViewController.h"
#import "ResetPasswordViewController.h"
#import "AFNetworking.h"
#import "MineViewController.h"

@interface SignUpViewController ()
@property (weak, nonatomic) IBOutlet UINavigationBar *signNavigationBar;
@property (weak, nonatomic) IBOutlet UITextField *accountField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *signUPButton;
@property (weak, nonatomic) IBOutlet UIButton *toRegister;
@property (weak, nonatomic) IBOutlet UIButton *forgetPassword;
@property (weak, nonatomic) IBOutlet UILabel *accountTip;
@property (weak, nonatomic) IBOutlet UILabel *passwordTip;


@end

@implementation SignUpViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    UIColor *fieldBorderColor;//颜色预设
    fieldBorderColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    
    //导航栏相关设置 start————————————————————————————————————————————————————————————————————————————————————————
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    self.navigationController.navigationBar.translucent=NO;
    self.navigationController.navigationBar.barTintColor=navColor;//设置背景颜色
    self.navigationItem.title=@"登录";//设置标题
    NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
    self.navigationController.navigationBar.titleTextAttributes =dic;//设置字体颜色
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:self action:nil];
    backItem.tintColor=[UIColor whiteColor];//设置返回按钮的颜色，同时上一句去掉了原本的返回语句
    self.navigationItem.backBarButtonItem = backItem;
    //导航栏相关设置 end————————————————————————————————————————————————————————————————————————————————————————
    
    _accountField.layer.borderWidth=2.0f;
    _accountField.layer.borderColor=fieldBorderColor.CGColor;//设置账号边框颜色，必须加上border width 否则无法查看效果
    _accountField.borderStyle=UITextBorderStyleRoundedRect;
    _accountField.layer.cornerRadius=8;
    
    _passwordField.layer.borderWidth=2.0f;
    _passwordField.layer.borderColor=fieldBorderColor.CGColor;
    _passwordField.borderStyle=UITextBorderStyleRoundedRect;
    _passwordField.layer.cornerRadius=8;
    
    [_toRegister addTarget:self action:@selector(toRegisterView) forControlEvents:UIControlEventTouchUpInside];
    [_forgetPassword addTarget:self action:@selector(toResetPasswordView) forControlEvents:UIControlEventTouchUpInside];
    
    [_signUPButton addTarget:self action:@selector(tapLogin) forControlEvents:UIControlEventTouchUpInside];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    self.tabBarController.tabBar.hidden = YES; // 隐藏tabBar
}
-(void)viewWillDisappear:(BOOL)animated{
    self.tabBarController.tabBar.hidden = NO; // 显示tabBar
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)toRegisterView
{
    RegisterViewController *regist=[[RegisterViewController alloc]init];
    [self.navigationController pushViewController:regist animated:YES];
}
-(void)toResetPasswordView
{
    ResetPasswordViewController *reset=[[ResetPasswordViewController alloc]init];
    [self.navigationController pushViewController:reset animated:YES];
}
-(void)tapLogin{
//    NSLog(@"%@", _accountField.text);
//    NSLog(@"%@", _passwordField.text);
    NSString *accountText =self.accountField.text;//输入的账号内容
    NSString *passwordText =self.passwordField.text;//输入的密码
    NSString *temp1 = [accountText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];//清空空格
    NSString *temp2 = [passwordText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];//清空空格

    self.passwordTip.text=@"";
    self.accountTip.text=@"";
    if(temp1.length!=0&&temp2.length!=0)
    {
        [self login];
    }
    else if (temp1.length!=0&&temp2.length==0)
    {
        self.passwordTip.text=@"密码不能为空";
        NSLog(@"密码不能为空");
    }
    else if (temp1.length==0&&temp2.length!=0)
    {
        self.accountTip.text=@"账号不能为空";
        NSLog(@"账号不能为空");
    }
    else
    {
        self.accountTip.text=@"请输入内容";
        self.passwordTip.text=@"请输入内容";
     NSLog(@"请输入内容");
    }
}
-(void)login{
    //1.创建会话管理者
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    //设置请求数据格式自动转换为JSON
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
//    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain",@"text/html", nil];
    
    NSDictionary *paramDict = @{
                                @"apicode":@"Login",
//                                @"user_account":_accountField.text
                                @"args":@{
                                        @"user_account":_accountField.text,
                                        @"user_password":_passwordField.text,
                                        }
                                };
    [manager POST:@"http://172.20.10.2:3000/log_in/login" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        
        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
        NSLog(@"%@---%@",[dic class],dic);  //打印返回信息
        
        if ([dic[@"rescode"] intValue]==2){//账

            self.passwordTip.text=@"账号或密码错误";
            NSLog(@"%@",@"账号或密码错误");
        }
        else{
            //获取userDefault单例
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            
            //登陆成功后把用户名和密码存储到UserDefault
            [userDefaults setObject:self.accountField.text forKey:@"name"];
//            [userDefaults setObject:password forKey:@"password"];
            [userDefaults synchronize];
//            [self.view setNeedsDisplay];
            [self.navigationController popViewControllerAnimated:NO];
            NSLog(@"%@",@"登录成功");
            
        }
//
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

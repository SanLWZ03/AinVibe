//
//  MineNavigationController.m
//  AinVibe
//
//  Created by DMT on 2018/12/2.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MineNavigationController.h"


@interface MineNavigationController ()

@end

@implementation MineNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    //设置状态栏颜色
    UIColor *barColor;
    barColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    [self setStatusBarBackgroundColor:barColor];
    
}

//设置状态栏背景颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}
//状态栏文字颜色
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
//点击其他位置 隐藏键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

@end

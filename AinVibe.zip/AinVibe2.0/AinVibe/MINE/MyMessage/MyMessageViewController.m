//
//  MyMessageViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/16.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyMessageViewController.h"
#import "MyMessageTableViewCell.h"
#import "AFNetworking.h"
@interface MyMessageViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *messageTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation MyMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor=[UIColor clearColor];
    self.navigationItem.title=@"我的消息";//设置标题
    [self fetchMessageInfomation];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.messageTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.messageTableView.delegate = self;
    self.messageTableView.dataSource = self;
    //添加到ViewController的视图中
    [self.view addSubview:self.messageTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    MyMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [MyMessageTableViewCell myMessageTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    NSString *messagerPicUrl=_dataArray[rowNO][@"message_sender_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:messagerPicUrl]];//转化为data
    cell.messageImage.image = [UIImage imageWithData:data];             //图片
    cell.messageImage.layer.cornerRadius=5;
    cell.messageImage.contentMode=UIViewContentModeScaleAspectFill;
    cell.messageImage.clipsToBounds=YES;
    cell.messageSender.text =_dataArray[rowNO][@"message_sender"];
    cell.messageSender.font=[UIFont systemFontOfSize:16.0];
    cell.messageSender.textColor = [UIColor blackColor];
    cell.messageSender.lineBreakMode = NSLineBreakByWordWrapping;
    cell.messageSender.numberOfLines = 0;
   
    cell.messageLogogram.text = _dataArray[rowNO][@"message_content"];
    cell.messageLogogram.font=[UIFont systemFontOfSize:16.0];
    cell.messageLogogram.lineBreakMode = NSLineBreakByWordWrapping;
    cell.messageLogogram.numberOfLines = 1;
    cell.messageLogogram.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
    cell.massageTime.text = _dataArray[rowNO][@"message_time"];
    cell.massageTime.font=[UIFont systemFontOfSize:16.0];
    cell.massageTime.lineBreakMode = NSLineBreakByWordWrapping;
    cell.massageTime.numberOfLines = 1;
    cell.massageTime.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}
- (void)fetchMessageInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/my_message" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        //        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

//
//  MineViewController.m
//  AinVibe
//
//  Created by DMT on 2018/11/30.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MineViewController.h"
#import "PersonalViewController.h"
#import "PersonalViewController.h"
#import "LOG/SignUpViewController.h"
#import "MyMessageViewController.h"
#import "MyFavoriteViewController.h"
#import "MyDownloadViewController.h"
#import "MyOrdersViewController.h"
#import "SettingsViewController.h"
#import "AFNetworking.h"

@interface MineViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) UITableView *mineTableView;
@property (nonatomic, strong) NSArray *mineTableTitle;
@property (nonatomic, strong) NSArray *mineTableImage;
@property (nonatomic, strong) UIImageView *personalPic;
@property (nonatomic, strong) UILabel *personalUserName;
@property (nonatomic, strong) UILabel *personalIntro;
@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [self.view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];//移除当前页面的所有东西，为重绘做准备
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *name = [userDefault objectForKey:@"name"];//判断是否登录
    if (name != nil)
    {
        NSLog(@"welcome,%@",name);
        
#pragma mark -- 导航栏
        //导航栏相关设置 start————————————————————————————————————————————————————————————————————————————————————————
        UIColor *navColor;//颜色预设 #171b27   (23 27 39)
        navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
        self.navigationController.navigationBar.translucent=NO;
        self.navigationController.navigationBar.barTintColor=navColor;//设置背景颜色
        self.navigationItem.title=@"Mine";//设置标题
        NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
        self.navigationController.navigationBar.titleTextAttributes =dic;//设置字体
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:self action:nil];
        backItem.tintColor=[UIColor whiteColor];//设置返回按钮的颜色，同时上一句去掉了原本的语句
        //    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"user.png"] style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];//测试   用图片代替，但是返回键仍然存在 同时颜色仍然为默认
        self.navigationItem.backBarButtonItem = backItem;
        //导航栏相关设置 end————————————————————————————————————————————————————————————————————————————————————————
#pragma mark -- 个人
        self.view.backgroundColor=[UIColor colorWithRed:246.0/255.0 green:246.0/255.0 blue:246.0/255.0 alpha:1];//personal view backgroundcolor
        
        CGRect personalSize=CGRectMake(0,0, 375, 100);//个人中心入口
        UIView *personalView= [[UIView alloc]initWithFrame:personalSize];
        personalView.backgroundColor=[UIColor whiteColor];
        personalView.userInteractionEnabled = YES;//打开交互
        UITapGestureRecognizer * tapMinePersonal = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toPersonalView)];
        //[tapMinePersonal setNumberOfTapsRequired:2];//触发事件需要的点击次数（默认单机触发）
        [personalView addGestureRecognizer:tapMinePersonal];
        //[personalView addTarget:self action:@selector(toHotBeatsView) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:personalView];//个人中心view添加
        //picture
        _personalPic=[[UIImageView alloc] init];                              // 个人头像
        _personalPic.backgroundColor=[UIColor blackColor];
        _personalPic.image=[UIImage imageNamed:@"unknown"];
        _personalPic.contentMode=UIViewContentModeScaleAspectFill;
        _personalPic.clipsToBounds=YES;
        _personalPic.frame=CGRectMake(20, 10, 80, 80);
        //圆形头像绘制--------------------------start
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:_personalPic.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:_personalPic.bounds.size];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
        //设置大小
        maskLayer.frame = _personalPic.bounds;
        //设置图形样子
        maskLayer.path = maskPath.CGPath;
        _personalPic.layer.mask = maskLayer;
        //圆形头像绘制---------------------------end
        [personalView addSubview:_personalPic];//添加图片到view中
        //username
        
        _personalUserName=[[UILabel alloc]init];                         //用户名
        _personalUserName.frame=CGRectMake(120,30, 190, 24);
        _personalUserName.text = @"用户名";
        _personalUserName.font=[UIFont systemFontOfSize:22.0];
        [personalView addSubview:_personalUserName];//添加username到view中
        //intro
        _personalIntro=[[UILabel alloc]init];                        //用户的签名
        _personalIntro.frame=CGRectMake(120,45, 190, 48);//高度设置为三倍，因为可能需要换行
        _personalIntro.text = @"签名";
        _personalIntro.font=[UIFont systemFontOfSize:16.0];
        UIColor *introLinesColor;//签名颜色预设 #B4B4B4   (180 180 180)
        introLinesColor=[UIColor colorWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:1];
        _personalIntro.textColor = introLinesColor;
        _personalIntro.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
        _personalIntro.numberOfLines = 0;//设置label文字显示的行数，默认值为：1，只用一行来显示，其他的>0的行数，文字会尽量按照设定行数来显示如果值为0：iOS会对文字自动计算所需要的行数，按照需要的行数来显示文字
        [personalView addSubview:_personalIntro];//添加签名label到view中
        //move to personal pic
        UIImageView *toPersonalPic=[[UIImageView alloc] init];
        toPersonalPic.image=[UIImage imageNamed:@"next.jpg"];
        toPersonalPic.frame=CGRectMake(330, 40, 25, 25);
        [personalView addSubview:toPersonalPic];//添加图片到view中
        
#pragma mark -- table
        self.mineTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,100, 375, 244) style:UITableViewStyleGrouped];
        self.mineTableView.scrollEnabled = NO;//禁止滑动
        self.mineTableView.backgroundColor = [UIColor clearColor];
        _mineTableTitle=@[@"我的消息",@"我的收藏",@"我的下载",@"我的订单",@"设置"];
        _mineTableImage=@[@"message",@"favorite",@"download",@"order",@"setting"];
        self.dataSource = [[NSMutableArray alloc] init];
        self.mineTableView.dataSource = self;
        self.mineTableView.delegate = self;
        [self.view addSubview:self.mineTableView];
        
        UILabel *serviceNumber = [[UILabel alloc]init];  //客服电话
        serviceNumber.frame=CGRectMake(120,560, 150, 18);//高度设置为三倍，因为可能需要换行
        serviceNumber.text = @"客服电话:1-800-273-8255";
        serviceNumber.font=[UIFont systemFontOfSize:11.0];
        serviceNumber.textColor = introLinesColor;
        [self.view addSubview:serviceNumber];
        
        UIButton *logOut=[UIButton buttonWithType:UIButtonTypeRoundedRect];//退出登录
        logOut.frame=CGRectMake(0,581, 375, 44);
        logOut.backgroundColor=[UIColor whiteColor];
        [logOut setTitle:@"退出登录" forState:UIControlStateNormal];
        UIColor *logOutColor;//颜色
        logOutColor=[UIColor colorWithRed:225.0/255.0 green:84.0/255.0 blue:74.0/255.0 alpha:1];
        [logOut setTitleColor:logOutColor forState:UIControlStateNormal];
        [logOut addTarget:self action:@selector(logOut) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:logOut];//添加按钮到view中
        [self fetchUserInfomation];
    }
    else
    {
#pragma mark -- 未登录导航栏
        //导航栏相关设置 start————————————————————————————————————————————————————————————————————————————————————————
        UIColor *navColor;//颜色预设 #171b27   (23 27 39)
        navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
        self.navigationController.navigationBar.translucent=NO;
        self.navigationController.navigationBar.barTintColor=navColor;//设置背景颜色
        self.navigationItem.title=@"Mine";//设置标题
        NSDictionary *dic = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
        self.navigationController.navigationBar.titleTextAttributes =dic;//设置字体
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithTitle:@"" style:UIBarButtonItemStyleDone target:self action:nil];
        backItem.tintColor=[UIColor whiteColor];//设置返回按钮的颜色，同时上一句去掉了原本的语句
        //    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"user.png"] style:UIBarButtonItemStylePlain target:self action:@selector(backAction)];//测试   用图片代替，但是返回键仍然存在 同时颜色仍然为默认
        self.navigationItem.backBarButtonItem = backItem;
        //导航栏相关设置 end————————————————————————————————————————————————————————————————————————————————————————
#pragma mark -- 未登录个人
        self.view.backgroundColor=[UIColor whiteColor];//personal view backgroundcolor
        
        
        //[personalView addTarget:self action:@selector(toHotBeatsView) forControlEvents:UIControlEventTouchUpInside];
        UIImageView *personalPic=[[UIImageView alloc] init];                       // 头像
        personalPic.image=[UIImage imageNamed:@"unknown"];
        personalPic.frame=CGRectMake(150, 200, 80, 80);
        //圆形头像绘制--------------------------start
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:personalPic.bounds byRoundingCorners:UIRectCornerAllCorners cornerRadii:personalPic.bounds.size];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc]init];
        //设置大小
        maskLayer.frame = personalPic.bounds;
        //设置图形样子
        maskLayer.path = maskPath.CGPath;
        personalPic.layer.mask = maskLayer;
        //圆形头像绘制---------------------------endic
        personalPic.userInteractionEnabled = YES;//打开交互
        UITapGestureRecognizer * tapPic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toSignUp)];
        [personalPic addGestureRecognizer:tapPic];//点击事件
        [self.view addSubview:personalPic];//添加图片到view中
        //立即登录
        //        UILabel *personalUserName=[[UILabel alloc]init];
        //        personalUserName.frame=CGRectMake(145,300, 190, 24);
        //        personalUserName.text = @"立即登录";
        //        personalUserName.font=[UIFont systemFontOfSize:22.0];
        //        UITapGestureRecognizer * tapLog = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toSignUp)];
        //        [personalPic addGestureRecognizer:tapLog];//点击事件
        //        [self.view addSubview:personalUserName];//添加username到view中
        UIButton *loginButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];//立即登录按钮
        loginButton.frame=CGRectMake(140,300, 100, 30);
        //hotBeatsButton.backgroundColor=[UIColor redColor];
        [loginButton setTitle:@"立即登录" forState:UIControlStateNormal];
        loginButton.layer.cornerRadius=15;
        loginButton.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:215.0/255.0 alpha:1];
        [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [loginButton addTarget:self action:@selector(toSignUp) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:loginButton];
        //intro
        UILabel *personalIntro=[[UILabel alloc]init];
        personalIntro.frame=CGRectMake(135,330, 190, 48);
        personalIntro.text = @"登录后更加精彩";
        personalIntro.font=[UIFont systemFontOfSize:16.0];
        UIColor *introLinesColor;//签名颜色预设 #B4B4B4   (180 180 180)
        introLinesColor=[UIColor colorWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:1];
        personalIntro.textColor = introLinesColor;
        personalIntro.lineBreakMode = NSLineBreakByWordWrapping;// 以单词为单位换行，以单词为单位截断。
        personalIntro.numberOfLines = 0;//设置label文字显示的行数，默认值为：1，只用一行来显示，其他的>0的行数，文字会尽量按照设定行数来显示如果值为0：iOS会对文字自动计算所需要的行数，按照需要的行数来显示文字
        [self.view addSubview:personalIntro];//添加签名label到view中
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self){
        //设置标签项的标题
        self.tabBarItem.title = @"MINE";
        
        //从图像文件创建一个UIImage对象，在retina屏幕上会加载hyno@2x.png
        UIImage *i = [UIImage imageNamed:@"user.png"];
        //将对象赋给标签项的Image
        self.tabBarItem.image = i;
    }
    return self;
}
-(void)toSignUp//去到登录界面
{
    SignUpViewController *signUpVC=[[SignUpViewController alloc]init];
    [self.navigationController pushViewController:signUpVC animated:YES];
}
//-(void)backAction
//{
//    [self.navigationController popViewControllerAnimated:YES];
//}
-(void)toPersonalView
{
    PersonalViewController *profile = [[PersonalViewController alloc]init];
    profile.username=_personalUserName.text;
    [self.navigationController pushViewController:profile animated:YES];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ///<1.>设置标识符
    static NSString * str = @"cellStr";
    ///<2.>复用机制:如果一个页面显示7个cell，系统则会创建8个cell,当用户向下滑动到第8个cell时，第一个cell进入复用池等待复用。
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:str];
    ///<3.>新建cell
    if (cell == nil) {
        //副标题样式
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    ///<4.>设置单元格上显示的文字信息
    NSUInteger rowNO=indexPath.row;
    if (indexPath.section == 0)
    {
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.imageView.image = [UIImage imageNamed:_mineTableImage[rowNO]];//图片
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }
    else if (indexPath.section ==1)
    {
        rowNO += 1;
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.imageView.image = [UIImage imageNamed:_mineTableImage[rowNO]];//图片
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }
    else
    {
        rowNO += 4;
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.imageView.image = [UIImage imageNamed:_mineTableImage[rowNO]];//图片
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }

    
    return cell;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{//section 数目
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {//每个section的行数
    if (section==0)
        return 1;
    else if (section==1)
        return 3;
    else
        return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 4;//section头部高度
}
//修改section的间距，间距b=头部间距+底部间距
//section头部视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 1)];
    view.backgroundColor = [UIColor clearColor];
    return view ;
}
//section底部间距
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 4;//底部间距
}
//section底部视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 1)];
    view.backgroundColor = [UIColor clearColor];
    return view;
}
-(void)logOut
{
//    NSLog(@"正在按按钮");
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"AinVibe" message:@"确认要退出登录吗？" preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(alertController) weakAlert = alertController;

    UIAlertAction *actionDefault = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"确认退出登录");
        //为了防止循环引用，在这里需要进行弱引用设置，下面如果有用到alertController的也需要做相同的处理
//        获取UserDefaults单例
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        //移除UserDefaults中存储的用户信息
        [userDefaults removeObjectForKey:@"name"];
        [userDefaults synchronize];
//        MineViewController *mineVC=[[MineViewController alloc]init];
        [self viewWillAppear:YES];
    }];
    [alertController addAction:actionDefault];

    UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"取消退出登录");
    }];
    [alertController addAction:actionCancel];
    [self presentViewController:alertController animated:YES completion:nil];

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section==0 && indexPath.row == 0) {//我的消息界面
        MyMessageViewController *messageVC = [[MyMessageViewController alloc]init];
        [self.navigationController pushViewController:messageVC animated:YES];
    }
    else if (indexPath.section==1 && indexPath.row == 0){//我的收藏界面
        MyFavoriteViewController *favoriteVC = [[MyFavoriteViewController alloc]init];
        [self.navigationController pushViewController:favoriteVC animated:YES];
    }
    else if (indexPath.section==1 && indexPath.row == 1){//我的下载界面
        MyDownloadViewController *downloadVC = [[MyDownloadViewController alloc]init];
        [self.navigationController pushViewController:downloadVC animated:YES];
    }
    else if (indexPath.section==1 && indexPath.row == 2){//我的订单界面
        MyOrdersViewController *ordersVC = [[MyOrdersViewController alloc]init];
        [self.navigationController pushViewController:ordersVC animated:YES];
    }
    else{
        SettingsViewController *settingsVC = [[SettingsViewController alloc]init];
        [self.navigationController pushViewController:settingsVC animated:YES];
    }
}
- (void)fetchUserInfomation //取得后台d用户信息
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/user_info/information" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_personalUserName.text=responseObject[0][@"user_name"];//设置用户名
        self->_personalIntro.text=responseObject[0][@"user_intro"];//设置用户签名
        NSString *profileUrl=responseObject[0][@"user_pic"];//设置r头像图片路径
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
        self->_personalPic.image = [UIImage imageWithData:data];//设置头像图片
        
//        NSLog(backgroundUrl);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}

@end

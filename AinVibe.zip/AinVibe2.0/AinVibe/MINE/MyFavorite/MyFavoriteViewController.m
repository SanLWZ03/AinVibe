//
//  MyFavoriteViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyFavoriteViewController.h"
#import "MyFavoriteBeatsViewController.h"
#import "MyFavoriteUsersViewController.h"
#import "MyFavoriteCdsViewController.h"

@interface MyFavoriteViewController ()<UIScrollViewDelegate>
@property (nonatomic,strong) UIView *navigationView;
@property (nonatomic,strong) UILabel *sliderLabel;
@property (nonatomic,strong) UIButton *beatsViewButton;
@property (nonatomic,strong) UIButton *usersViewButton;
@property (nonatomic,strong) UIButton *cdsViewButton;
@property (nonatomic,strong) UIScrollView *myFavoriteMainScrollView;
//@property (nonatomic,strong) MyFavoriteBeatsViewController *beatsVC;
//@property (nonatomic,strong) MyFavoriteUsersViewController *usersVC;
//@property (nonatomic,strong) MyFavoriteCdsViewController *cdsVC;
@end

@implementation MyFavoriteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.title=@"我的收藏";//设置标题.
    _myFavoriteMainScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 375, 641)];
    _myFavoriteMainScrollView.delegate = self;
    _myFavoriteMainScrollView.backgroundColor = [UIColor whiteColor];
    _myFavoriteMainScrollView.pagingEnabled = YES;
    self.myFavoriteMainScrollView.bounces = NO;
    _myFavoriteMainScrollView.showsHorizontalScrollIndicator = NO;
    _myFavoriteMainScrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_myFavoriteMainScrollView];
    
    MyFavoriteBeatsViewController *beatsVC = [[MyFavoriteBeatsViewController alloc]init];
    MyFavoriteUsersViewController *usersVC = [[MyFavoriteUsersViewController alloc]init];
    MyFavoriteCdsViewController *cdsVC = [[MyFavoriteCdsViewController alloc]init];
    
    NSArray *views = @[beatsVC.view, usersVC.view,cdsVC.view];
    for (int i = 0; i < views.count; i++){
        //添加背景，把VC的view贴到mainScrollView上面
        UIView *pageView = [[UIView alloc]initWithFrame:CGRectMake(375 * i, 0, _myFavoriteMainScrollView.frame.size.width, _myFavoriteMainScrollView.frame.size.height)];
        [pageView addSubview:views[i]];
        [_myFavoriteMainScrollView addSubview:pageView];
    }
    [self addChildViewController:beatsVC];//   解决了自定义tablecell在scrollview中自动消失的问题
    [self addChildViewController:usersVC];
    [self addChildViewController:cdsVC];
    _myFavoriteMainScrollView.contentSize = CGSizeMake(375 * (views.count), 641);
    [self initUI];//初始化导航栏
}

//初始化UIBtton和一个滑动的UILabel，命名为sliderLabel
-(void)initUI{
    
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    _navigationView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, 40)];
    
    _navigationView.backgroundColor = [UIColor whiteColor];
    _sliderLabel = [[UILabel alloc]initWithFrame:CGRectMake(40, 0, 90, 40)];
    _sliderLabel.backgroundColor = [UIColor colorWithRed:93.0/255.0 green:194.0/255.0 blue:255.0/255.0 alpha:1];
    _sliderLabel.layer.cornerRadius=20;
    _sliderLabel.layer.masksToBounds = YES;
    [_navigationView addSubview:_sliderLabel];
    
    _beatsViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _beatsViewButton.frame = CGRectMake(40, 0, 90, 40);
    _beatsViewButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [_beatsViewButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_beatsViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_beatsViewButton setTitle:@"BEATS" forState:UIControlStateNormal];
    _beatsViewButton.tag = 1;
    [_navigationView addSubview:_beatsViewButton];
    
    
    _usersViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _usersViewButton.frame = CGRectMake(142.5, 0, 90, 40);
    _usersViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [_usersViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_usersViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_usersViewButton setTitle:@"USERS" forState:UIControlStateNormal];
    _usersViewButton.tag = 2;
    [_navigationView addSubview:_usersViewButton];
    
    _cdsViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _cdsViewButton.frame = CGRectMake(245, 0, 90, 40);
    _cdsViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [_cdsViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_cdsViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_cdsViewButton setTitle:@"CDS" forState:UIControlStateNormal];
    _cdsViewButton.tag = 3;
    [_navigationView addSubview:_cdsViewButton];
    
    [self.view addSubview:_navigationView];
}


-(UIButton *)theSeletedBtn{
    if (_beatsViewButton.selected) {
        return _beatsViewButton;
    }else if (_usersViewButton.selected){
        return _usersViewButton;
    }else if (_cdsViewButton.selected){
        return _cdsViewButton;
    }
    else{
        return nil;
    }
}
-(UIButton *)buttonWithTag:(NSInteger)tag{//根据tag返回 按钮
    if (tag==1) {
        return _beatsViewButton;
    }else if (tag==2){
        return _usersViewButton;
    }else if (tag==3){
        return _cdsViewButton;
    }else{
        return nil;
    }
}


-(void)sliderAction:(UIButton *)sender{//点击导航栏的两个按钮会到这个函数，并且会有一个sender
    [self sliderAnimationWithTag:sender.tag];//获取sender的tag值，传到sliderAnimationWithTag函数中
    [UIView animateWithDuration:0.3 animations:^{
        self.myFavoriteMainScrollView.contentOffset = CGPointMake(375 * (sender.tag - 1), 0);//根据tag的值修改scrollView的显示界面
    } completion:^(BOOL finished) {
        
    }];
    
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{//让scrollview的滑动也能触发label的滑动动画
    double index = scrollView.contentOffset.x / 375;//当前的偏移量除以屏幕宽度，就是当前横向滑动占屏幕宽度的百分比
    [self sliderAnimationWithTag:(int)(index+0.5)+1];//index+0.5是为了当屏幕滑动超过宽度的一半时 label的滑动动画就触发。(滑到一半时，index=0.5，此时，tag=2，刚好是选中第二个按钮时的tag值)
}
#pragma mark - sliderLabel滑动动画
- (void)sliderAnimationWithTag:(NSInteger)tag{//根据传过来的tag值对选中按钮进行操作
    _beatsViewButton.selected = NO;
    _usersViewButton.selected = NO;
    _cdsViewButton.selected = NO;
    UIButton *sender = [self buttonWithTag:tag];//将选中的按钮
    sender.selected = YES;
    //动画
    [UIView animateWithDuration:0.3 animations:^{//duration为动画持续的时间。最好和前面的sliderAction一样，否则一前一后感觉动画断开了，效果不好
        self.sliderLabel.frame = CGRectMake(sender.frame.origin.x, self.sliderLabel.frame.origin.y, self.sliderLabel.frame.size.width, self.sliderLabel.frame.size.height);//将label的位置设置为选中的下方
        
    } completion:^(BOOL finished) {
        self.beatsViewButton.titleLabel.font = [UIFont systemFontOfSize:16];//按钮都设置为默认
        self.usersViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
        self.cdsViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [self.beatsViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.usersViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self.cdsViewButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [sender setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        sender.titleLabel.font = [UIFont boldSystemFontOfSize:16];//把选中的按钮字体加大加粗
    }];
    
}

@end

//
//  MyFavoriteCdsTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyFavoriteCdsTableViewCell : UITableViewCell
+(instancetype)myFavoriteCdsTableViewCell;
@property (weak, nonatomic) IBOutlet UIImageView *cdPic;
@property (weak, nonatomic) IBOutlet UILabel *cdName;
@property (weak, nonatomic) IBOutlet UILabel *cdSinger;
@property (weak, nonatomic) IBOutlet UIButton *deleteButton;
@end

NS_ASSUME_NONNULL_END

//
//  MyFavoriteUsersTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyFavoriteUsersTableViewCell : UITableViewCell
+(instancetype)myFavoriteUsersTableViewCell;
@property (weak, nonatomic) IBOutlet UIImageView *usersPic;
@property (weak, nonatomic) IBOutlet UILabel *usersName;
@property (weak, nonatomic) IBOutlet UILabel *usersIntro;
@property (weak, nonatomic) IBOutlet UIImageView *favoriteButton;


@end

NS_ASSUME_NONNULL_END

//
//  MyFavoriteCdsViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyFavoriteCdsViewController.h"
#import "MyFavoriteCdsTableViewCell.h"
#import "AFNetworking.h"
@interface MyFavoriteCdsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *favoriteCdsTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation MyFavoriteCdsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self fetchFavoriteCDsInfomation];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.favoriteCdsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.favoriteCdsTableView.delegate = self;
    self.favoriteCdsTableView.dataSource = self;
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 375, 44)];
    self.favoriteCdsTableView.tableHeaderView = headerView;
    //添加到ViewController的视图中
    [self.view addSubview:self.favoriteCdsTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    MyFavoriteCdsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [MyFavoriteCdsTableViewCell myFavoriteCdsTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//取消CELL的点击效果
    NSString *profileUrl=_dataArray[rowNO][@"favorite_cd_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
    cell.cdPic.image = [UIImage imageWithData:data];             //图片
    cell.cdPic.contentMode=UIViewContentModeScaleAspectFill;
    cell.cdPic.clipsToBounds=YES;
    cell.cdName.text = _dataArray[rowNO][@"favorite_cd_name"];
    cell.cdSinger.text = _dataArray[rowNO][@"favorite_cd_producer"];
    [cell.deleteButton addTarget:self action:@selector(stopFavorite:) forControlEvents:UIControlEventTouchUpInside];
  
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 90;
}
-(void)stopFavorite:(UIButton *)sender{
    MyFavoriteCdsTableViewCell *currentCell = (MyFavoriteCdsTableViewCell *)[[sender superview]superview];
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:currentCell.cdName.text message:@"确认要取消收藏吗？" preferredStyle:UIAlertControllerStyleAlert];
    __weak typeof(alertController) weakAlert = alertController;
    
    UIAlertAction *actionDefault = [UIAlertAction actionWithTitle:@"确认" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"确认取消收藏");
        //为了防止循环引用，在这里需要进行弱引用设置，下面如果有用到alertController的也需要做相同的处理
        //        MineViewController *mineVC=[[MineViewController alloc]init];
        AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
        manager.requestSerializer = [AFJSONRequestSerializer serializer];
        
        NSDictionary *paramDict = @{
                                    @"apicode":@"userinfo",
                                    //                                @"user_account":_accountField.text
                                    @"args":@{
                                            @"user_name":currentCell.cdName.text,
                                            //                                        @"user_password":_passwordField.text,
                                            }
                                    };
        [manager POST:@"http://172.20.10.2:3000/user_info/stop_favorite_cd" parameters:paramDict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            //        NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:nil];
            [self viewDidLoad];
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"请求失败--%@",error);
        }];
    }];
    [alertController addAction:actionDefault];
    
    UIAlertAction *actionCancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"取消操作");
    }];
    [alertController addAction:actionCancel];
    [self presentViewController:alertController animated:YES completion:nil];
    
}
- (void)fetchFavoriteCDsInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/favorite_cds" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

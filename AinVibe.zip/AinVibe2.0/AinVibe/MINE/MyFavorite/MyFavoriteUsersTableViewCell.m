//
//  MyFavoriteUsersTableViewCell.m
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyFavoriteUsersTableViewCell.h"

@implementation MyFavoriteUsersTableViewCell
+(instancetype)myFavoriteUsersTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"MyFavoriteUsersTableViewCell" owner:nil options:nil] lastObject];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

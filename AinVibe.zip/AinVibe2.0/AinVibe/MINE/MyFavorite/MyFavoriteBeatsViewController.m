//
//  MyFavoriteBeatsViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyFavoriteBeatsViewController.h"
#import "MyFavoriteBeatsTableViewCell.h"
#import "AFNetworking.h"
@interface MyFavoriteBeatsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *favoriteBeatsTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@end

@implementation MyFavoriteBeatsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [self fetchFavoriteBeatsInfomation];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.favoriteBeatsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.favoriteBeatsTableView.delegate = self;
    self.favoriteBeatsTableView.dataSource = self;
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 375, 44)];
    self.favoriteBeatsTableView.tableHeaderView = headerView;
    //添加到ViewController的视图中
    [self.view addSubview:self.favoriteBeatsTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    MyFavoriteBeatsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [MyFavoriteBeatsTableViewCell myFavoriteBeatsTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    NSString *order=[NSString stringWithFormat: @"%lu", (unsigned long)rowNO+1];    //编号
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//取消CELL的点击效果
    cell.number.text = order;
    cell.number.textAlignment = UITextAlignmentCenter;
    cell.number.textColor = [UIColor blackColor];;
    cell.beatsName.text = _dataArray[rowNO][@"beats_name"];
    cell.beatsName.textColor = [UIColor blackColor];
    cell.beatsAlbum.text = _dataArray[rowNO][@"beats_album_name"];
    cell.beatsAlbum.font=[UIFont systemFontOfSize:16.0];
    cell.beatsAlbum.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];
    cell.play.image = [UIImage imageNamed:@"favorite"];             //图片
    cell.play.contentMode=UIViewContentModeScaleAspectFill;
    cell.play.clipsToBounds=YES;
    cell.download.image = [UIImage imageNamed:@"downloadsong"];             //图片
    cell.download.contentMode=UIViewContentModeScaleAspectFill;
    cell.download.clipsToBounds=YES;
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}
- (void)fetchFavoriteBeatsInfomation
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/download" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self config];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
@end

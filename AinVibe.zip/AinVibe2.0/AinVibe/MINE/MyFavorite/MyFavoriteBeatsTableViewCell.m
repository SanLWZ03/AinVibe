//
//  MyFavoriteBeatsTableViewCell.m
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "MyFavoriteBeatsTableViewCell.h"

@implementation MyFavoriteBeatsTableViewCell
+(instancetype)myFavoriteBeatsTableViewCell{
    return [[[NSBundle mainBundle] loadNibNamed:@"MyFavoriteBeatsTableViewCell" owner:nil options:nil] lastObject];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

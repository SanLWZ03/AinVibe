//
//  MyFavoriteBeatsTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyFavoriteBeatsTableViewCell : UITableViewCell
+(instancetype)myFavoriteBeatsTableViewCell;
@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *beatsName;
@property (weak, nonatomic) IBOutlet UILabel *beatsAlbum;
@property (weak, nonatomic) IBOutlet UIImageView *play;
@property (weak, nonatomic) IBOutlet UIImageView *download;
@end

NS_ASSUME_NONNULL_END

//
//  MyOrdersTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyOrdersTableViewCell : UITableViewCell
+(instancetype)myOrdersTableViewCell;
@property (weak, nonatomic) IBOutlet UIView *orderMainView;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UIView *orderView;
@property (weak, nonatomic) IBOutlet UIImageView *orderImage;
@property (weak, nonatomic) IBOutlet UILabel *orderName;
@property (weak, nonatomic) IBOutlet UILabel *orderAmount;
@property (weak, nonatomic) IBOutlet UILabel *orderPrice;
@property (weak, nonatomic) IBOutlet UIButton *orderButton;
@end

NS_ASSUME_NONNULL_END

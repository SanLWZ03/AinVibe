//
//  SettingsViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/23.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "SettingsViewController.h"

@interface SettingsViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) UITableView *mineTableView;
@property (nonatomic, strong) NSArray *mineTableTitle;
@end

@implementation SettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.title=@"设置";//设置标题
    
#pragma mark -- table
    self.mineTableView = [[UITableView alloc] initWithFrame:CGRectMake(0,30, 375, 540) style:UITableViewStyleGrouped];
    self.mineTableView.scrollEnabled = NO;//禁止滑动
    self.mineTableView.backgroundColor = [UIColor clearColor];
    _mineTableTitle=@[@"安全设置",@"隐私设置",@"修改密码",@"播放设置",@"下载设置",@"界面设置",@"清除缓存"];
    self.dataSource = [[NSMutableArray alloc] init];
    self.mineTableView.dataSource = self;
    self.mineTableView.delegate = self;
    [self.view addSubview:self.mineTableView];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ///<1.>设置标识符
    static NSString * str = @"cellStr";
    ///<2.>复用机制:如果一个页面显示7个cell，系统则会创建8个cell,当用户向下滑动到第8个cell时，第一个cell进入复用池等待复用。
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:str];
    ///<3.>新建cell
    if (cell == nil) {
        //副标题样式
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    ///<4.>设置单元格上显示的文字信息
    NSUInteger rowNO=indexPath.row;
    if (indexPath.section == 0)
    {
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }
    else if (indexPath.section ==1)
    {
        rowNO += 3;
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }
    else
    {
        rowNO += 6;
        cell.textLabel.text = _mineTableTitle[rowNO];//标题
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;//右边箭头
    }
    
    
    return cell;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{//section 数目
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {//每个section的行数
    if (section==0)
        return 3;
    else if (section==1)
        return 3;
    else
        return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;//section头部高度
}
//修改section的间距，间距b=头部间距+底部间距
//section头部视图
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 1)];
    view.backgroundColor = [UIColor clearColor];
    return view ;
}
//section底部间距
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 10;//底部间距
}
//section底部视图
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView *view=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 1)];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

@end

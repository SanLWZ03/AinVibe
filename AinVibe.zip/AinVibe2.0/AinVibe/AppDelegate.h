//
//  AppDelegate.h
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDB.h"
#import <sqlite3.h>
@class GAViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) FMDatabase* sqlitedb;
@property (strong, nonatomic) GAViewController *viewController;
-(FMDatabase*) shareDb;

@end


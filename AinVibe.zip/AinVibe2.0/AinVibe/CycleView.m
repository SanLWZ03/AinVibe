//
//  CycleView.m
//  SimplePictureCarouselScrollView
//
//  Created by admin on 16/8/26.
//  Copyright © 2016年 Derrick_Qin. All rights reserved.
//

#import "CycleView.h"

#define kImageCount _picDataArray.count
#define kMargin 20
#define kPageControlW 100
#define kPageControlH 25
static void RGBtoHSV( float r, float g, float b, float *h, float *s, float *v )
{
    float min, max, delta;
    min = MIN( r, MIN( g, b ));
    max = MAX( r, MAX( g, b ));
    *v = max;               // v
    delta = max - min;
    if( max != 0 )
        *s = delta / max;       // s
    else {
        // r = g = b = 0        // s = 0, v is undefined
        *s = 0;
        *h = -1;
        return;
    }
    if( r == max )
        *h = ( g - b ) / delta;     // between yellow & magenta
    else if( g == max )
        *h = 2 + ( b - r ) / delta; // between cyan & yellow
    else
        *h = 4 + ( r - g ) / delta; // between magenta & cyan
    *h *= 60;               // degrees
    if( *h < 0 )
        *h += 360;
}

@interface CycleView () <UIScrollViewDelegate>
@property(nonatomic, weak) UIScrollView *mainScrollView;
@property(nonatomic, weak) UIImageView *centerImageView;
@property(nonatomic, weak) UIImageView *leftImageView;
@property(nonatomic, weak) UIImageView *rightImageView;
@property(nonatomic, assign) NSInteger leftImageIndex;
@property(nonatomic, assign) NSInteger rightImageIndex;
@property(nonatomic, weak) UIPageControl *pageControl;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) CGRect PageControlFrame;

@end

@implementation CycleView

- (instancetype)initWithFrame:(CGRect)frame {

  self = [super initWithFrame:frame];

  if (self) {
    [self setupSubviews];
    [self setupPageControl];
  }
  return self;
}

- (void)scrollViewClick:(UITapGestureRecognizer *)tap {

  if ([self.delegate respondsToSelector:@selector(whenCycleClick:)]) {

    [self.delegate whenCycleClick:self.currentImageIndex];
  }
}

- (void)setPicDataArray:(NSArray *)picDataArray {
  _picDataArray = picDataArray;

  _pageControl.numberOfPages = picDataArray.count;

  [self reloadImageViews];
}

- (void)setupSubviews {

  UIScrollView *mainScrollView = [[UIScrollView alloc]
      initWithFrame:CGRectMake(0, 0, self.bounds.size.width,
                               self.bounds.size.height)];

  mainScrollView.contentSize = CGSizeMake(self.bounds.size.width * 3, 0);

  mainScrollView.bounces = NO;//取消到最后时的反弹效果 对本例子影响不大

  mainScrollView.pagingEnabled = YES;

  mainScrollView.showsHorizontalScrollIndicator = NO;

  mainScrollView.showsVerticalScrollIndicator = NO;

  [mainScrollView setBackgroundColor:[UIColor clearColor]];

  _mainScrollView = mainScrollView;

  _mainScrollView.delegate = self;

  [self addSubview:mainScrollView];

  [_mainScrollView setContentOffset:CGPointMake(self.bounds.size.width, 0)
                           animated:NO];

  UIImageView *leftImageView = [[UIImageView alloc]//因为我自己想要做图片不充满的效果z所以改了一下宽度
      initWithFrame:CGRectMake(15, 0, 345,self.bounds.size.height)];
  _leftImageView = leftImageView;
  _leftImageView.contentMode=UIViewContentModeScaleAspectFill;

  UIImageView *rightImageView =
      [[UIImageView alloc] initWithFrame:CGRectMake(765,
                                                    0, 345,
                                                    self.bounds.size.height)];//两倍+15
  _rightImageView = rightImageView;
  _rightImageView.contentMode=UIViewContentModeScaleAspectFill;
  UIImageView *centerImageView =
      [[UIImageView alloc] initWithFrame:CGRectMake(390, 0,
                                                    345,
                                                    self.bounds.size.height)];

  centerImageView.userInteractionEnabled = YES;

  _centerImageView = centerImageView;
  _centerImageView.contentMode=UIViewContentModeScaleAspectFill;
  UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
      initWithTarget:self
              action:@selector(scrollViewClick:)];

  [centerImageView addGestureRecognizer:tap];

  [self.mainScrollView addSubview:leftImageView];
  [self.mainScrollView addSubview:rightImageView];
  [self.mainScrollView addSubview:centerImageView];

  [_mainScrollView
      setContentOffset:CGPointMake(_mainScrollView.bounds.size.width, 0)
              animated:NO];
}

- (void)setupPageControl {

  UIPageControl *pageControl = [[UIPageControl alloc] init];

  pageControl.numberOfPages = _picDataArray.count;

  _pageControl = pageControl;

  pageControl.tintColor = _pageControlTintColor;

  pageControl.currentPageIndicatorTintColor = _pageControlCurrentColor;

  [self addSubview:pageControl];
}

- (void)automaticScroll {

  CGPoint currentPoint = _mainScrollView.contentOffset;

  currentPoint.x += _mainScrollView.bounds.size.width;

  [_mainScrollView setContentOffset:currentPoint animated:YES];
}

- (void)setIsAutomaticScroll:(BOOL)isAutomaticScroll {

  _isAutomaticScroll = isAutomaticScroll;

  [self endMyTimer];

  if (isAutomaticScroll) {
    [self startMyTimer];
  }
}

- (NSInteger)leftImageIndex {

  if (_currentImageIndex == 0) {

    _leftImageIndex = kImageCount - 1;

  } else {

    _leftImageIndex = _currentImageIndex - 1;
  }

  return _leftImageIndex;
}

- (NSInteger)rightImageIndex {

  if (_currentImageIndex == kImageCount - 1) {

    _rightImageIndex = 0;
  } else {

    _rightImageIndex = _currentImageIndex + 1;
  }

  return _rightImageIndex;
}

- (void)currentImageIndexAdd {

  if (self.currentImageIndex == kImageCount - 1) {

    self.currentImageIndex = 0;
  } else {
    self.currentImageIndex = self.currentImageIndex + 1;
  }
}

- (void)currentImageIndexMinus {

  if (self.currentImageIndex == 0) {

    self.currentImageIndex = kImageCount - 1;

  } else {

    self.currentImageIndex = self.currentImageIndex - 1;
  }
}

- (void)reloadImageViews {

  CGPoint scrollViewOffset = [_mainScrollView contentOffset];

  if (scrollViewOffset.x == 2 * _mainScrollView.bounds.size.width) {

    [self currentImageIndexAdd];

  } else if (scrollViewOffset.x == 0) {

    [self currentImageIndexMinus];
  }

  _centerImageView.image =
      [UIImage imageNamed:_picDataArray[self.currentImageIndex]];
    //UIImage *testImage=_centerImageView.image;
  _currentImageName = _picDataArray[self.currentImageIndex];
  _leftImageView.image =
      [UIImage imageNamed:_picDataArray[self.leftImageIndex]];
  _rightImageView.image =
      [UIImage imageNamed:_picDataArray[self.rightImageIndex]];
  UIColor *loginC = [self mostColor:_centerImageView.image];
    _mainScrollView.backgroundColor=loginC;
  _pageControl.currentPage = self.currentImageIndex;
}

- (void)startMyTimer {

  if (self.isAutomaticScroll) {
    NSTimer *newTimer =
        [NSTimer scheduledTimerWithTimeInterval:self.automaticScrollDelay
                                         target:self
                                       selector:@selector(automaticScroll)
                                       userInfo:nil
                                        repeats:YES];

    _timer = newTimer;

    [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
  }
}

- (void)endMyTimer {

  if (self.isAutomaticScroll) {
    [_timer invalidate];

    _timer = nil;
  }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView
                  willDecelerate:(BOOL)decelerate {

  [self startMyTimer];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {

  [self endMyTimer];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {

  CGPoint scrollViewOffset = scrollView.contentOffset;

  if (scrollViewOffset.x > 1.5 * _mainScrollView.bounds.size.width) {

    _pageControl.currentPage = self.rightImageIndex;


  } else if (scrollViewOffset.x < 0.5 * _mainScrollView.bounds.size.width) {

    _pageControl.currentPage = self.leftImageIndex;

  }

  else {
    _pageControl.currentPage = self.currentImageIndex;

  }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {

  [self reloadImageViews];

  [_mainScrollView
      setContentOffset:CGPointMake(_mainScrollView.bounds.size.width, 0)
              animated:NO];
}
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {

  [self reloadImageViews];

  [_mainScrollView
      setContentOffset:CGPointMake(_mainScrollView.bounds.size.width, 0)
              animated:NO];
}

- (NSUInteger)currentImageIndex {

  if (!_currentImageIndex) {

    _currentImageIndex = 0;
  }

  return _currentImageIndex;
}

- (void)setPageControlTintColor:(UIColor *)pageControlTintColor {
  _pageControlTintColor = pageControlTintColor;

  _pageControl.tintColor = pageControlTintColor;
}

- (void)setPageControlCurrentColor:(UIColor *)pageControlCurrentColor {
  _pageControlCurrentColor = pageControlCurrentColor;

  _pageControl.currentPageIndicatorTintColor = pageControlCurrentColor;
}

- (float)automaticScrollDelay {

  if (!_automaticScrollDelay) {
    _automaticScrollDelay = 2.0;
  }

  return _automaticScrollDelay;
}

- (void)setAutomaticScrollDelay:(float)automaticScrollDelay {

  _automaticScrollDelay = automaticScrollDelay;

  [self setIsAutomaticScroll:self.isAutomaticScroll];
}

- (CycleViewStyle)cycleViewStyle {

  if (!_cycleViewStyle) {

    _cycleViewStyle = CycleViewStylePageControl;
  }

  return _cycleViewStyle;
}

- (void)setCycleViewStyle:(CycleViewStyle)cycleViewStyle {

  _cycleViewStyle = cycleViewStyle;

  if (cycleViewStyle == CycleViewStyleNone) {
    _PageControlFrame = CGRectZero;
  } else if (cycleViewStyle == CycleViewStylePageControl) {
    _PageControlFrame = CGRectMake((self.bounds.size.width - kPageControlW) / 2,
                                   self.bounds.size.height - kPageControlH,
                                   kPageControlW, kPageControlH);
  } else if (cycleViewStyle == CycleViewStyleBoth) {
    _PageControlFrame = CGRectMake(
        self.bounds.size.width - kPageControlW - kMargin,
        self.bounds.size.height - kPageControlH, kPageControlW, kPageControlH);
  }

  _pageControl.frame = _PageControlFrame;
}
//主色调作为背景颜色
-(UIColor*)mostColor:(UIImage*)image{
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED > __IPHONE_6_1
    int bitmapInfo = kCGBitmapByteOrderDefault | kCGImageAlphaPremultipliedLast;
#else
    int bitmapInfo = kCGImageAlphaPremultipliedLast;
#endif
    
    //第一步 先把图片缩小 加快计算速度. 但越小结果误差可能越大
    CGSize thumbSize=CGSizeMake(40, 40);
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    CGContextRef context = CGBitmapContextCreate(NULL,
                                                 thumbSize.width,
                                                 thumbSize.height,
                                                 8,//bits per component
                                                 thumbSize.width*4,
                                                 colorSpace,
                                                 bitmapInfo);
    
    CGRect drawRect = CGRectMake(0, 0, thumbSize.width, thumbSize.height);
    CGContextDrawImage(context, drawRect, image.CGImage);
    CGColorSpaceRelease(colorSpace);
    
    //第二步 取每个点的像素值
    unsigned char* data = CGBitmapContextGetData (context);
    
    if (data == NULL) return nil;
    NSArray *MaxColor=nil;
    // NSCountedSet *cls=[NSCountedSet setWithCapacity:thumbSize.width*thumbSize.height];
    float maxScore=0;
    for (int x=0; x<thumbSize.width*thumbSize.height; x++) {
        
        int offset = 4*x;
        int red = data[offset];
        int green = data[offset+1];
        int blue = data[offset+2];
        int alpha =  data[offset+3];
        
        if (alpha<25)continue;
        
        float h,s,v;
        
        RGBtoHSV(red, green, blue, &h, &s, &v);
        
        float y = MIN(abs(red*2104+green*4130+blue*802+4096+131072)>>13, 235);
        y= (y-16)/(235-16);
        if (y>0.9) continue;
        
        float score = (s+0.1)*x;
        if (score>maxScore) {
            maxScore = score;
        }
        MaxColor=@[@(red),@(green),@(blue),@(alpha)];
        
    }
    
    CGContextRelease(context);
    return [UIColor colorWithRed:([MaxColor[0] intValue]/255.0f) green:([MaxColor[1] intValue]/255.0f) blue:([MaxColor[2] intValue]/255.0f) alpha:([MaxColor[3] intValue]/255.0f)];
}
@end

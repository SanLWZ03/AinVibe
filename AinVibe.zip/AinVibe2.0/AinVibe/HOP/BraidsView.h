//
//  BraidsView.h
//  AinVibe
//
//  Created by GO on 2018/12/14.
//  Copyright © 2018 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BraidsView : UIView

@end

NS_ASSUME_NONNULL_END

//
//  TattoosViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/14.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "TattoosViewController.h"
#import "TattoosView.h"
#import "AFNetworking.h"
#import "TattoosTableViewCell.h"
#import "OthersProfileViewController.h"
@interface TattoosViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UITableView *tattoosTableView;
@property (nonatomic, strong) UIScrollView *tattoosMainScrollView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *postsArray;
@end

@implementation TattoosViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _tattoosMainScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 375, 641)];
    [self.view addSubview:_tattoosMainScrollView];
    [self fetchInfomation];
}
- (void)fetchInfomation //取得后台d用户信息
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/tattoo" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self fetchPosts];//获取内容
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)fetchPosts{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/tattooPosts" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_postsArray=[[NSMutableArray alloc]init];
        self->_postsArray=responseObject;//设置数组
        [self config];//加载页面
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.tattoosTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.tattoosTableView.delegate = self;
    self.tattoosTableView.dataSource = self;
    //添加到ViewController的视图中
    [self.view addSubview:self.tattoosTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    TattoosTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [TattoosTableViewCell tattoosTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    self.tattoosTableView.separatorStyle = UITableViewCellSeparatorStyleNone;//取消分割线
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//取消CELL的点击效果
    cell.tattooView.backgroundColor=[UIColor whiteColor];//         view
    cell.tattooView.layer.cornerRadius = 10;
    cell.tattooView.layer.shadowColor = [UIColor blackColor].CGColor;
    cell.tattooView.layer.shadowOffset = CGSizeMake(0, 15);
    cell.tattooView.layer.shadowOpacity = 0.1;
    cell.tattooView.layer.shadowRadius = 10;
    NSString *postUrl=_postsArray[rowNO][@"post_pic"];
    NSData * data2 = [NSData dataWithContentsOfURL:[NSURL URLWithString:postUrl]];//转化为data
    cell.tattooPostPic.image = [UIImage imageWithData:data2];             //图片
//    cell.tattooPostPic.contentMode=UIViewContentModeScaleAspectFill;
//    cell.tattooPostPic.clipsToBounds=YES;
    cell.tattooPostTime.text = _postsArray[rowNO][@"post_time"];              //发布时间
//    cell.tattooPostTime.font=[UIFont systemFontOfSize:14.0];
//    cell.tattooPostTime.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
    cell.tattooPostContent.text = _postsArray[rowNO][@"post_content"];     //标题
//    cell.postTitle.font=[UIFont systemFontOfSize:16.0];
//    cell.postTitle.textColor = [UIColor blackColor];
    cell.tattooPostContent.lineBreakMode = NSLineBreakByWordWrapping;
    cell.tattooPostContent.numberOfLines = 0;
    //上传者的头像
    NSString *profileUrl=_dataArray[rowNO][@"user_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
    cell.tattooUploaderPic.image=[UIImage imageWithData:data];
    cell.tattooUploaderPic.contentMode=UIViewContentModeScaleAspectFill;
    cell.tattooUploaderPic.layer.cornerRadius=5;
    cell.tattooUploaderPic.clipsToBounds=YES;
    //上传者的username;
    cell.tattooUploaderName.text = _dataArray[rowNO][@"user_name"];
//    cell.tattooUploaderName.font=[UIFont systemFontOfSize:17.0];
//    cell.tattooUploaderName.textColor = [UIColor blackColor];
    //上传者的签名
    cell.tattooUploaderIntro.text = _dataArray[rowNO][@"user_intro"];
//    cell.uploaderIntro.font=[UIFont systemFontOfSize:16.0];
//    cell.uploaderIntro.lineBreakMode = NSLineBreakByWordWrapping;
//    cell.uploaderIntro.numberOfLines = 1;
//    cell.uploaderIntro.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
    //查看详情按钮
    [cell.tattooViewMoreButton addTarget:self action:@selector(toDetailView:) forControlEvents:UIControlEventTouchUpInside];
    //    cell.viewMoreButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
    //    cell.viewMoreButton.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:255.0/255.0 alpha:1];
    //    cell.viewMoreButton.layer.cornerRadius=15;
    //    cell.viewMoreButton.titleLabel.font = [UIFont systemFontOfSize: 14.0];
    //    [cell.viewMoreButton setTitle:@"查看更多" forState:UIControlStateNormal];
    //    [cell.viewMoreButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    //    返回当前cell
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 375;
}

-(void)toDetailView:(UIButton *)sender{
    OthersProfileViewController *profileVC = [[OthersProfileViewController alloc]init];
    TattoosTableViewCell *currentCell = (TattoosTableViewCell *)[[[sender superview]superview]superview];
    //    NSLog(@"%@dsfadgdsgsdgdsfgds", currentCell.uploaderName.text);
    profileVC.username = currentCell.tattooUploaderName.text;
    [self.navigationController pushViewController:profileVC animated:YES];
}
//-(void)loadBraids{
//    for (int i = 1; i <= _dataArray.count; i++) {
//
//        TattoosView *tattoosView;//view
//        tattoosView = [[TattoosView alloc]initWithFrame:CGRectMake(25, 30*i+(i-1)*350, 325, 350)];
//        CGRect scrollsize = CGRectMake(0,0, 375, 380*i);
//        _tattoosMainScrollView.contentSize = scrollsize.size ;
//        [_tattoosMainScrollView addSubview:tattoosView];
//        UIImageView *uploader;//上传者的头像
//        uploader=[[UIImageView alloc]initWithFrame:CGRectMake(15, 15, 50, 50)];
//        NSString *profileUrl=_dataArray[i-1][@"user_pic"];//设置头像图片路径
//        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
//        uploader.image=[UIImage imageWithData:data];
//        uploader.contentMode=UIViewContentModeScaleAspectFill;
//        uploader.layer.cornerRadius=5;
//        uploader.clipsToBounds=YES;
//        [tattoosView addSubview:uploader];
//        UILabel *uploaderName;//上传者的username
//        uploaderName=[[UILabel alloc]init];
//        uploaderName.frame=CGRectMake(80,20, 150, 20);
//        uploaderName.text = _dataArray[i-1][@"user_name"];
//        uploaderName.font=[UIFont systemFontOfSize:17.0];
//        uploaderName.textColor = [UIColor blackColor];
//        [tattoosView addSubview:uploaderName];
//        UILabel *uploaderIntro;//上传者的签名
//        uploaderIntro=[[UILabel alloc]init];
//        uploaderIntro.frame=CGRectMake(80,45, 150, 20);
//        uploaderIntro.text = _dataArray[i-1][@"user_intro"];
//        uploaderIntro.font=[UIFont systemFontOfSize:16.0];
//        uploaderIntro.lineBreakMode = NSLineBreakByWordWrapping;
//        uploaderIntro.numberOfLines = 1;
//        uploaderIntro.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
//        [tattoosView addSubview:uploaderIntro];
//        UILabel *postTime;//发布时间
//        postTime=[[UILabel alloc]init];
//        postTime.frame=CGRectMake(250,40, 60, 14);
//        postTime.text = _postsArray[i-1][@"post_time"];
//        postTime.font=[UIFont systemFontOfSize:14.0];
//        postTime.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
//        [tattoosView addSubview:postTime];
//        UIImageView *tattoosImageView;//view 图片
//        tattoosImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 70, 325, 200)];
//        NSString *postUrl=_postsArray[i-1][@"post_pic"];
//        NSData * data2 = [NSData dataWithContentsOfURL:[NSURL URLWithString:postUrl]];//转化为data
//        tattoosImageView.image=[UIImage imageWithData:data2];
//        tattoosImageView.contentMode=UIViewContentModeScaleAspectFill;
//        tattoosImageView.clipsToBounds=YES;
//        //    tattoosImageView.userInteractionEnabled = YES;//打开交互
//        //    UITapGestureRecognizer * tapProfileBackgroundPic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeProfileBackgroundModal)];
//        //    [tattoosImageView addGestureRecognizer:tapProfileBackgroundPic];
//        [tattoosView addSubview:tattoosImageView];
//
//        UILabel *postTitle;//标题
//        postTitle=[[UILabel alloc]init];
//        postTitle.frame=CGRectMake(15,280, 200, 60);
//        postTitle.text =_postsArray[i-1][@"post_content"];
//        postTitle.font=[UIFont systemFontOfSize:16.0];
//        postTitle.textColor = [UIColor blackColor];
//        postTitle.lineBreakMode = NSLineBreakByWordWrapping;
//        postTitle.numberOfLines = 0;
//        [tattoosView addSubview:postTitle];
//        UIButton *readMore;//查看详情按钮
//        readMore=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//        readMore.frame=CGRectMake(230,300, 80, 30);
//        readMore.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:255.0/255.0 alpha:1];
//        readMore.layer.cornerRadius=15;
//        readMore.titleLabel.font = [UIFont systemFontOfSize: 14.0];
//        [readMore setTitle:@"查看更多" forState:UIControlStateNormal];
//        [readMore setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [tattoosView addSubview:readMore];
//    }
//}

@end

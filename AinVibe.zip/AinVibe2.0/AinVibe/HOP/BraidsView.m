//
//  BraidsView.m
//  AinVibe
//
//  Created by GO on 2018/12/14.
//  Copyright © 2018 AinVibe. All rights reserved.
//

#import "BraidsView.h"

@implementation BraidsView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor whiteColor];
        self.layer.cornerRadius = 10;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 15);
        self.layer.shadowOpacity = 0.1;
        self.layer.shadowRadius = 10;
    }
    return self;
}
@end

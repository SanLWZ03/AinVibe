//
//  TattoosTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/26.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TattoosTableViewCell : UITableViewCell
+(instancetype)tattoosTableViewCell;
@property (weak, nonatomic) IBOutlet UIView *tattooView;
@property (weak, nonatomic) IBOutlet UIImageView *tattooUploaderPic;
@property (weak, nonatomic) IBOutlet UILabel *tattooUploaderName;
@property (weak, nonatomic) IBOutlet UILabel *tattooUploaderIntro;
@property (weak, nonatomic) IBOutlet UILabel *tattooPostTime;
@property (weak, nonatomic) IBOutlet UIImageView *tattooPostPic;
@property (weak, nonatomic) IBOutlet UILabel *tattooPostContent;
@property (weak, nonatomic) IBOutlet UIButton *tattooViewMoreButton;
@end

NS_ASSUME_NONNULL_END

//
//  HopViewController.m
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "HopViewController.h"
#import "BraidsViewController.h"
#import "TattoosViewController.h"

@interface HopViewController ()<UIScrollViewDelegate>
@property (nonatomic,strong) UIView *navigationView;
@property (nonatomic,strong) UILabel *sliderLabel;
@property (nonatomic,strong) UIButton *braidsViewButton;
@property (nonatomic,strong) UIButton *tattoosViewButton;
@property (nonatomic,strong) UIScrollView *hopMainScrollView;
@property (nonatomic,strong) BraidsViewController *braidsVC;
@property (nonatomic,strong) TattoosViewController *tattoosVC;
@end

@implementation HopViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initUI];//初始化导航栏
    
    _hopMainScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 375, 641)];
    _hopMainScrollView.delegate = self;
    _hopMainScrollView.backgroundColor = [UIColor whiteColor];
    _hopMainScrollView.pagingEnabled = YES;
    _hopMainScrollView.showsHorizontalScrollIndicator = NO;
    _hopMainScrollView.showsVerticalScrollIndicator = NO;
    [self.view addSubview:_hopMainScrollView];
    
    BraidsViewController *braidsVC = [[BraidsViewController alloc]init];
    TattoosViewController *tattoosVC = [[TattoosViewController alloc]init];
    
    NSArray *views = @[braidsVC.view, tattoosVC.view];
    for (int i = 0; i < views.count; i++){
        //添加背景，把VC的view贴到mainScrollView上面
        UIView *pageView = [[UIView alloc]initWithFrame:CGRectMake(375 * i, 0, _hopMainScrollView.frame.size.width, _hopMainScrollView.frame.size.height)];
        [pageView addSubview:views[i]];
        [_hopMainScrollView addSubview:pageView];
    }
    [self addChildViewController:braidsVC];
    [self addChildViewController:tattoosVC];
    _hopMainScrollView.contentSize = CGSizeMake(375 * (views.count), 0);
}
//初始化UIBtton和一个滑动的UILabel，命名为sliderLabel
-(void)initUI{
    
    UIColor *navColor;//颜色预设 #171b27   (23 27 39)
    navColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    _navigationView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 375, 44)];
    _navigationView.backgroundColor = navColor;
    _braidsViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _braidsViewButton.frame = CGRectMake(5, 0, 90, 44);
    _braidsViewButton.titleLabel.font = [UIFont boldSystemFontOfSize:19];
    [_braidsViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_braidsViewButton setTitle:@"BRAIDS" forState:UIControlStateNormal];
    _braidsViewButton.tag = 1;
    [_navigationView addSubview:_braidsViewButton];
    
    
    _tattoosViewButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _tattoosViewButton.frame = CGRectMake(90, 0, 90, 44);
    _tattoosViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
    [_tattoosViewButton addTarget:self action:@selector(sliderAction:) forControlEvents:UIControlEventTouchUpInside];
    [_tattoosViewButton setTitle:@"TATTOOS" forState:UIControlStateNormal];
    _tattoosViewButton.tag = 2;
    [_navigationView addSubview:_tattoosViewButton];
    
    _sliderLabel = [[UILabel alloc]initWithFrame:CGRectMake(5, 40, 90, 4)];
    _sliderLabel.backgroundColor = [UIColor colorWithRed:93.0/255.0 green:194.0/255.0 blue:255.0/255.0 alpha:1];
    [_navigationView addSubview:_sliderLabel];
    self.navigationController.navigationBar.barTintColor=navColor;
    self.navigationController.navigationBar.translucent=NO;
    self.navigationItem.titleView = _navigationView;
}


-(UIButton *)theSeletedBtn{
    if (_braidsViewButton.selected) {
        return _braidsViewButton;
    }else if (_tattoosViewButton.selected){
        return _tattoosViewButton;
    }
    else{
        return nil;
    }
}
-(UIButton *)buttonWithTag:(NSInteger)tag{//根据tag返回 按钮
    if (tag==1) {
        return _braidsViewButton;
    }else if (tag==2){
        return _tattoosViewButton;
    }else{
        return nil;
    }
}


-(void)sliderAction:(UIButton *)sender{//点击导航栏的两个按钮会到这个函数，并且会有一个sender
    [self sliderAnimationWithTag:sender.tag];//获取sender的tag值，传到sliderAnimationWithTag函数中
    [UIView animateWithDuration:0.3 animations:^{
        self.hopMainScrollView.contentOffset = CGPointMake(375 * (sender.tag - 1), 0);//根据tag的值修改scrollView的显示界面
    } completion:^(BOOL finished) {
        
    }];
    
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{//让scrollview的滑动也能触发label的滑动动画
    double index = scrollView.contentOffset.x / 375;//当前的偏移量除以屏幕宽度，就是当前横向滑动占屏幕宽度的百分比
    [self sliderAnimationWithTag:(int)(index+0.5)+1];//index+0.5是为了当屏幕滑动超过宽度的一半时 label的滑动动画就触发。(滑到一半时，index=0.5，此时，tag=2，刚好是选中第二个按钮时的tag值)
}
#pragma mark - sliderLabel滑动动画
- (void)sliderAnimationWithTag:(NSInteger)tag{//根据传过来的tag值对选中按钮进行操作
    _braidsViewButton.selected = NO;
    _tattoosViewButton.selected = NO;
    UIButton *sender = [self buttonWithTag:tag];//将选中的按钮
    sender.selected = YES;
    //动画
    [UIView animateWithDuration:0.3 animations:^{//duration为动画持续的时间。最好和前面的sliderAction一样，否则一前一后感觉动画断开了，效果不好
        self.sliderLabel.frame = CGRectMake(sender.frame.origin.x, self.sliderLabel.frame.origin.y, self.sliderLabel.frame.size.width, self.sliderLabel.frame.size.height);//将label的位置设置为选中的下方
        
    } completion:^(BOOL finished) {
        self.braidsViewButton.titleLabel.font = [UIFont systemFontOfSize:16];//按钮都设置为默认
        self.tattoosViewButton.titleLabel.font = [UIFont systemFontOfSize:16];
        
        sender.titleLabel.font = [UIFont boldSystemFontOfSize:19];//把选中的按钮字体加大加粗
    }];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if(self){
        //设置标签项的标题
        self.tabBarItem.title = @"HOP";
        
        //从图像文件创建一个UIImage对象，在retina屏幕上会加载hyno@2x.png
        UIImage *i = [UIImage imageNamed:@"HOP.png"];
        //将对象赋给标签项的Image
        self.tabBarItem.image = i;
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    //设置状态栏颜色
    UIColor *barColor;
    barColor=[UIColor colorWithRed:23.0/255.0 green:27.0/255.0 blue:39.0/255.0 alpha:1];
    [self setStatusBarBackgroundColor:barColor];
    
}

//设置状态栏背景颜色
- (void)setStatusBarBackgroundColor:(UIColor *)color {
    
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = color;
    }
}
//状态栏文字颜色
- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}
//点击其他位置 隐藏键盘
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
@end

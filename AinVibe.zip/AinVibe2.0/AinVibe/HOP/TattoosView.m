//
//  TattoosView.m
//  AinVibe
//
//  Created by DMT on 2018/12/15.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "TattoosView.h"

@implementation TattoosView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor=[UIColor whiteColor];
        self.layer.cornerRadius = 10;
        self.layer.shadowColor = [UIColor blackColor].CGColor;
        self.layer.shadowOffset = CGSizeMake(0, 15);
        self.layer.shadowOpacity = 0.1;
        self.layer.shadowRadius = 10;
    }
    return self;
}

@end

//
//  BraidsViewController.m
//  AinVibe
//
//  Created by DMT on 2018/12/14.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "BraidsViewController.h"
#import "BraidsView.h"
#import "BraidsTableViewCell.h"
#import "OthersProfileViewController.h"
#import "AFNetworking.h"
@interface BraidsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong) UIScrollView *braidsMainScrollView;
@property (nonatomic, strong) UITableView *braidsTableView;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) NSMutableArray *postsArray;
@end

@implementation BraidsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor=[UIColor clearColor];
   
    
//    _braidsMainScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, 375, 641)];
//    [self.view addSubview:_braidsMainScrollView];
    [self fetchInfomation];
//    [self.braidsTableView reloadData];
    
//     [self config];
//
}
- (void)fetchInfomation //取得后台d用户信息
{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/braids" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_dataArray=[[NSMutableArray alloc]init];
        self->_dataArray=responseObject;//设置数组
        [self fetchPosts];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}
-(void)fetchPosts{
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFJSONRequestSerializer serializer];
    
    [manager GET:@"http://172.20.10.2:3000/hopData/braidsPosts" parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        NSLog(@"%@---%@",[responseObject class],responseObject);
        self->_postsArray=[[NSMutableArray alloc]init];
        self->_postsArray=responseObject;//设置数组
        [self config];
        [self.braidsTableView reloadData];
        NSLog(@"%lu--",(unsigned long)self->_dataArray.count);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"请求失败--%@",error);
    }];
}

-(void)config {
    //初始化tableView,并给tableView设置frame以及样式
    self.braidsTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 375, 641) style:UITableViewStylePlain];
    //遵守代理和数据源(因为要用到代理和数据源方法)
    self.braidsTableView.delegate = self;
    self.braidsTableView.dataSource = self;
    //添加到ViewController的视图中
    [self.view addSubview:self.braidsTableView];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _dataArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //指定cell的重用标识符
    static NSString *reuseIdentifier = @"CELL";
    //去缓存池找名叫reuseIdentifier的cell
    //这里换成自己定义的cell
    BraidsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    //如果缓存池中没有,那么创建一个新的cell
    if (!cell) {
        //这里换成自己定义的cell,并调用类方法加载xib文件
        cell = [BraidsTableViewCell braidsTableViewCell];
    }
    //给cell赋值
    NSUInteger rowNO=indexPath.row;
    self.braidsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;//取消分割线
    cell.selectionStyle = UITableViewCellSelectionStyleNone;//取消CELL的点击效果
    cell.braidsView.backgroundColor=[UIColor whiteColor];//         view
    cell.braidsView.layer.cornerRadius = 10;
    cell.braidsView.layer.shadowColor = [UIColor blackColor].CGColor;
    cell.braidsView.layer.shadowOffset = CGSizeMake(0, 15);
    cell.braidsView.layer.shadowOpacity = 0.1;
    cell.braidsView.layer.shadowRadius = 10;
    NSString *postUrl=_postsArray[rowNO][@"post_pic"];
    NSData * data2 = [NSData dataWithContentsOfURL:[NSURL URLWithString:postUrl]];//转化为data
    cell.braidsPic.image = [UIImage imageWithData:data2];             //图片
    cell.braidsPic.contentMode=UIViewContentModeScaleAspectFill;
    //绘制自定数目圆角 要设置的圆角 使用“|”来组合
    UIBezierPath *maskPath;
    maskPath = [UIBezierPath bezierPathWithRoundedRect:cell.braidsPic.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(10, 10)];//左上和右上
    CAShapeLayer *maskLayer;
    maskLayer = [[CAShapeLayer alloc] init];
    //设置大小
    maskLayer.frame = cell.braidsPic.bounds;
    //设置图形样子
    maskLayer.path = maskPath.CGPath;
    cell.braidsPic.layer.mask = maskLayer;
    //绘制自定数目圆角-------------------------------------------------------end
    cell.braidsPic.clipsToBounds=YES;
    cell.postTime.text = _postsArray[rowNO][@"post_time"];              //发布时间
    cell.postTime.font=[UIFont systemFontOfSize:14.0];
    cell.postTime.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
    cell.postTitle.text = _postsArray[rowNO][@"post_content"];     //标题
    cell.postTitle.font=[UIFont systemFontOfSize:16.0];
    cell.postTitle.textColor = [UIColor blackColor];
    cell.postTitle.lineBreakMode = NSLineBreakByWordWrapping;
    cell.postTitle.numberOfLines = 0;
                                                                //上传者的头像
    NSString *profileUrl=_dataArray[rowNO][@"user_pic"];//设置头像图片路径
    NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
    cell.uploaderPic.image=[UIImage imageWithData:data];
    cell.uploaderPic.contentMode=UIViewContentModeScaleAspectFill;
    cell.uploaderPic.layer.cornerRadius=5;
    cell.uploaderPic.clipsToBounds=YES;
                                                          //上传者的username;
    cell.uploaderName.text = _dataArray[rowNO][@"user_name"];
    cell.uploaderName.font=[UIFont systemFontOfSize:17.0];
    cell.uploaderName.textColor = [UIColor blackColor];
                                                           //上传者的签名
    cell.uploaderIntro.text = _dataArray[rowNO][@"user_intro"];
    cell.uploaderIntro.font=[UIFont systemFontOfSize:16.0];
    cell.uploaderIntro.lineBreakMode = NSLineBreakByWordWrapping;
    cell.uploaderIntro.numberOfLines = 1;
    cell.uploaderIntro.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
                                                     //查看详情按钮
    [cell.viewMoreButton addTarget:self action:@selector(toDetailView:) forControlEvents:UIControlEventTouchUpInside];
//    cell.viewMoreButton=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//    cell.viewMoreButton.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:255.0/255.0 alpha:1];
//    cell.viewMoreButton.layer.cornerRadius=15;
//    cell.viewMoreButton.titleLabel.font = [UIFont systemFontOfSize: 14.0];
//    [cell.viewMoreButton setTitle:@"查看更多" forState:UIControlStateNormal];
//    [cell.viewMoreButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//    返回当前cell
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 375;
}

-(void)toDetailView:(UIButton *)sender{
//    NSLog(@"42asdasfasfs");
    OthersProfileViewController *profileVC = [[OthersProfileViewController alloc]init];
    BraidsTableViewCell *currentCell = (BraidsTableViewCell *)[[[sender superview]superview]superview];
//    NSLog(@"%@dsfadgdsgsdgdsfgds", currentCell.uploaderName.text);
    profileVC.username = currentCell.uploaderName.text;
    [self.navigationController pushViewController:profileVC animated:YES];
}

//-(void)loadInterface{
//    for (int i = 1; i <= _dataArray.count; i++) {
//
//        BraidsView *braidsView;//view
//        braidsView = [[BraidsView alloc]initWithFrame:CGRectMake(25, 30*i+(i-1)*350, 325, 350)];
//        CGRect scrollsize = CGRectMake(0,0, 375, 380*i);
//        _braidsMainScrollView.contentSize = scrollsize.size ;
//        [_braidsMainScrollView addSubview:braidsView];
//        UIImageView *braidsImageView;//view 图片
//        braidsImageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 325, 200)];
//        braidsImageView.image=[UIImage imageNamed:@"braids1"];
//        braidsImageView.contentMode=UIViewContentModeScaleAspectFill;
//        //绘制自定数目圆角 要设置的圆角 使用“|”来组合
//        UIBezierPath *maskPath;
//        maskPath = [UIBezierPath bezierPathWithRoundedRect:braidsImageView.bounds byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(10, 10)];//左上和右上
//        CAShapeLayer *maskLayer;
//        maskLayer = [[CAShapeLayer alloc] init];
//        //设置大小
//        maskLayer.frame = braidsImageView.bounds;
//        //设置图形样子
//        maskLayer.path = maskPath.CGPath;
//        braidsImageView.layer.mask = maskLayer;
//        //绘制自定数目圆角-------------------------------------------------------end
//        braidsImageView.clipsToBounds=YES;
//        braidsImageView.tag=1001;
//        //    braidsImageView1.userInteractionEnabled = YES;//打开交互
//        //    UITapGestureRecognizer * tapProfileBackgroundPic = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeProfileBackgroundModal)];
//        //    [braidsImageView1 addGestureRecognizer:tapProfileBackgroundPic];
//        [braidsView addSubview:braidsImageView];
//        UILabel *postTime;//发布时间
//        postTime=[[UILabel alloc]init];
//        postTime.frame=CGRectMake(250,210, 60, 14);
//        postTime.text = @"12小时前";
//        postTime.font=[UIFont systemFontOfSize:14.0];
//        postTime.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
//        [braidsView addSubview:postTime];
//        UILabel *postTitle;//标题
//        postTitle=[[UILabel alloc]init];
//        postTitle.frame=CGRectMake(15,230, 295, 40);
//        postTitle.text = @"If young metro don't trust you i gon' shoot you.";
//        postTitle.font=[UIFont systemFontOfSize:16.0];
//        postTitle.textColor = [UIColor blackColor];
//        postTitle.lineBreakMode = NSLineBreakByWordWrapping;
//        postTitle.numberOfLines = 0;
//        [braidsView addSubview:postTitle];
//        UIImageView *uploader;//上传者的头像
//        uploader=[[UIImageView alloc]initWithFrame:CGRectMake(15, 285, 50, 50)];
//        NSString *profileUrl=_dataArray[i-1][@"user_pic"];//设置头像图片路径
//        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:profileUrl]];//转化为data
//        uploader.image=[UIImage imageWithData:data];//获取图片
//        uploader.contentMode=UIViewContentModeScaleAspectFill;
//        uploader.layer.cornerRadius=5;
//        uploader.clipsToBounds=YES;
//        [braidsView addSubview:uploader];
//        UILabel *uploaderName;//上传者的username
//        uploaderName=[[UILabel alloc]init];
//        uploaderName.frame=CGRectMake(80,290, 150, 20);
//        uploaderName.text = _dataArray[i-1][@"user_name"];
//        uploaderName.font=[UIFont systemFontOfSize:17.0];
//        uploaderName.textColor = [UIColor blackColor];
//        [braidsView addSubview:uploaderName];
//        UILabel *uploaderIntro;//上传者的签名
//        uploaderIntro=[[UILabel alloc]init];
//        uploaderIntro.frame=CGRectMake(80,315, 150, 20);
//        uploaderIntro.text = _dataArray[i-1][@"user_intro"];
//        uploaderIntro.font=[UIFont systemFontOfSize:16.0];
//        uploaderIntro.lineBreakMode = NSLineBreakByWordWrapping;
//        uploaderIntro.numberOfLines = 1;
//        uploaderIntro.textColor = [UIColor colorWithRed:200.0/255.0 green:200.0/255.0 blue:200.0/255.0 alpha:1];;
//        [braidsView addSubview:uploaderIntro];
//        UIButton *readMore;//查看详情按钮
//        readMore=[UIButton buttonWithType:UIButtonTypeRoundedRect];
//        readMore.frame=CGRectMake(230,300, 80, 30);
//        readMore.backgroundColor=[UIColor colorWithRed:135.0/255.0 green:153.0/255.0 blue:255.0/255.0 alpha:1];
//        readMore.layer.cornerRadius=15;
////        readMore.layer.opacity=0;
//
//        readMore.titleLabel.font = [UIFont systemFontOfSize: 14.0];
//        [readMore setTitle:@"查看更多" forState:UIControlStateNormal];
//        [readMore setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        [readMore addTarget:self action:@selector(toUserProfile:) forControlEvents:UIControlEventTouchUpInside];
//        [braidsView addSubview:readMore];
//    }
//}

//-(void)toUserProfile:(UIButton *)sender{
//    BraidsView *view=[[BraidsView alloc]init];
//    view=[sender superview];
//    [view viewWithTag:1001].image=
//}
@end

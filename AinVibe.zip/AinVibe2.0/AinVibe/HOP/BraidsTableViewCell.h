//
//  BraidsTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/20.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BraidsTableViewCell : UITableViewCell
+(instancetype)braidsTableViewCell;
@property (weak, nonatomic) IBOutlet UIView *braidsView;
@property (weak, nonatomic) IBOutlet UIImageView *braidsPic;
@property (weak, nonatomic) IBOutlet UILabel *postTime;
@property (weak, nonatomic) IBOutlet UILabel *postTitle;
@property (weak, nonatomic) IBOutlet UIImageView *uploaderPic;
@property (weak, nonatomic) IBOutlet UILabel *uploaderName;
@property (weak, nonatomic) IBOutlet UILabel *uploaderIntro;
@property (weak, nonatomic) IBOutlet UIButton *viewMoreButton;

@end

NS_ASSUME_NONNULL_END

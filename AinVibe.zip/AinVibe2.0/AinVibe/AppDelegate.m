//
//  AppDelegate.m
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginNavigationController.h"
#import "SignUpViewController.h"
#import "HomeNavigationController.h"
#import "HomePageViewController.h"
#import "BeatsViewController.h"
#import "HopViewController.h"
#import "CDViewController.h"
#import "MineNavigationController.h"
#import "MineViewController.h"
#import "HopNavigationController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
//    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//    // Override point for customization after application launch.
//
//    // Create a BNRItemsViewController
//    SignUpViewController *signViewController = [[SignUpViewController alloc] init];
//
//    // Place a BNRItemsViewController's table view in the window hierarchy
//    //self.window.rootViewController = itemsViewController;
//    LoginNavigationController *navController=[[LoginNavigationController alloc]initWithRootViewController:signViewController];
//    self.window.rootViewController = navController;
//
//    self.window.backgroundColor = [UIColor whiteColor];
//    [self.window makeKeyAndVisible];
//    return YES;
    
    
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    
    HomePageViewController *homeVC=[[HomePageViewController alloc]init];
    HomeNavigationController *homeNavigation=[[HomeNavigationController alloc]initWithRootViewController:homeVC];
    
//    BeatsViewController *beatsVC=[[BeatsViewController alloc]init];
    
    HopViewController *hopVC=[[HopViewController alloc]init];
    HopNavigationController *hopNavigation=[[HopNavigationController alloc]initWithRootViewController:hopVC];
    
//    CDViewController *cdVC=[[CDViewController alloc]init];
    
    MineViewController *mineVC=[[MineViewController alloc]init];
    MineNavigationController *mineNavigation=[[MineNavigationController alloc]initWithRootViewController:mineVC];
    
    UITabBarController *tabBarController = [[UITabBarController alloc]init];
    tabBarController.viewControllers = @[homeNavigation,hopNavigation,mineNavigation];
    
    self.window.rootViewController = tabBarController;
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}
- (FMDatabase*) shareDb{
    
    if (_sqlitedb) return _sqlitedb ;
    
    //1.获得数据库文件的路径
    NSString *doc =[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES)  lastObject];
    
    NSString *dbPath = [doc stringByAppendingPathComponent:@"nerdfeed.sqlite"];
    
    _sqlitedb = [FMDatabase databaseWithPath:dbPath];
    if ([_sqlitedb open]) {
        BOOL result1 = [_sqlitedb executeUpdate:@"DROP TABLE IF EXISTS courses"];
        BOOL result2 = [_sqlitedb executeUpdate:@"CREATE TABLE IF NOT EXISTS courses (id integer PRIMARY KEY AUTOINCREMENT, title text NOT NULL);"];
        if (result2)
        {
            NSLog(@"创建表成功");
            [_sqlitedb executeUpdate:@"INSERT INTO courses (title) VALUES (?);",@"著名说唱歌手xxxtentacion遭遇枪击身亡 年仅20岁"];
            [_sqlitedb executeUpdate:@"INSERT INTO courses (title) VALUES (?);",@"Nas推出服装产品线"];
            [_sqlitedb executeUpdate:@"INSERT INTO courses (title) VALUES (?);",@"Drake继续回应和Pusha T的beef"];
        }
    } else {
        NSLog(@"数据库打开失败");
        return nil;
    }
    return _sqlitedb;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


@end

//
//  HotBeatsTableViewCell.h
//  AinVibe
//
//  Created by DMT on 2018/12/24.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HotBeatsTableViewCell : UITableViewCell
+(instancetype)hotBeatsTableViewCell;
@property (weak, nonatomic) IBOutlet UILabel *beatsNumber;
@property (weak, nonatomic) IBOutlet UIImageView *beatsPic;
@property (weak, nonatomic) IBOutlet UILabel *beatsName;
@property (weak, nonatomic) IBOutlet UILabel *beatsProducer;
@property (weak, nonatomic) IBOutlet UIImageView *downloadPic;
@property (weak, nonatomic) IBOutlet UIImageView *playPic;
@end

NS_ASSUME_NONNULL_END

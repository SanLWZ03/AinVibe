//
//  HotBeatsViewController.h
//  AinVibe
//
//  Created by DMT on 2018/12/2.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import <AudioToolbox/AudioToolbox.h>
NS_ASSUME_NONNULL_BEGIN

@interface HotBeatsViewController : UIViewController

@end

NS_ASSUME_NONNULL_END

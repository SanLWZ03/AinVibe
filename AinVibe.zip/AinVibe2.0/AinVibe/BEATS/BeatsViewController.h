//
//  BeatsViewController.h
//  AinVibe
//
//  Created by DMT on 2018/11/29.
//  Copyright © 2018年 AinVibe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BeatsViewController : UIViewController

@end
